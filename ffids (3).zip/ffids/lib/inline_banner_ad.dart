import 'dart:developer';

import 'package:ffids_dark/core/admob_ad_ids.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

enum AdMobInlineBannerType { small, medium, large }

class AdMobInlineBannerAd extends StatefulWidget {
  final AdMobInlineBannerType size;
  const AdMobInlineBannerAd({required this.size, super.key});

  @override
  State<AdMobInlineBannerAd> createState() => _AdMobInlineBannerAdState();
}

class _AdMobInlineBannerAdState extends State<AdMobInlineBannerAd> {
  late BannerAd _inlineBannerAd;
  bool _isInlineBannerAdLoaded = false;

  void _createInlineBannerAd() {
    _inlineBannerAd = BannerAd(
      size: adSizeByType(widget.size),
      adUnitId: AdmobIds.admobBannerAdId,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() {
          _isInlineBannerAdLoaded = true;
          log("Banner Ad Loaded Successfully");
        }),
        onAdFailedToLoad: (ad, error) {
          debugPrint("Banner Ad load failed: ${error.message}");
          ad.dispose();
        },
      ),
    );
    _inlineBannerAd.load();
  }

  @override
  void initState() {
    super.initState();
    _createInlineBannerAd();
  }

  @override
  void dispose() {
    super.dispose();
    _inlineBannerAd.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isInlineBannerAdLoaded) {
      return SizedBox(
        width: MediaQuery.of(context).size.width,
        height: 50,
        child: AdWidget(ad: _inlineBannerAd),
      );
    } else {
      return SizedBox(
        width: MediaQuery.of(context).size.width,
        height: 50,
        child: const Center(child: Text("Advertisement")),
      );
    }
  }
}

AdSize adSizeByType(AdMobInlineBannerType type) {
  if (type == AdMobInlineBannerType.small) {
    return AdSize.banner;
  } else if (type == AdMobInlineBannerType.medium) {
    return AdSize.largeBanner;
  } else if (type == AdMobInlineBannerType.large) {
    return AdSize.mediumRectangle;
  } else {
    throw UnimplementedError();
  }
}
