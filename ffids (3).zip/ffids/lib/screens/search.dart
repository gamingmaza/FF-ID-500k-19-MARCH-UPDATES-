import 'package:flutter/material.dart';

import '../data/constants.dart';
import '../models/post_model.dart';
import '../models/search_query_model.dart';
import '../services/firestore_service.dart';
import '../widgets/posts_listtile.dart';
import '../widgets/search_form.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key, required this.searchQueryModel});

  final SearchQueryModel searchQueryModel;

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List<PostModel>? searchResult;
  // final AdxInterstitialAdController interstitialAdController =
  //     AdxInterstitialAdController();
  // @override
  // void initState() {
  //   search(widget.searchQueryModel);
  //   super.initState();
  //   interstitialAdController.initializeInterstitialAds();
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.keyboard_backspace_rounded),
        ),
        title: Text(
          "Search",
          style: Theme.of(context).textTheme.titleMedium,
        ),
      ),
      body: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.all(defaultPadding),
            sliver: SliverList(
              delegate: SliverChildListDelegate.fixed([
                SearchForm(
                    initialValue: widget.searchQueryModel, onSearch: search),
                if (widget.searchQueryModel.queryText != null)
                  const SizedBox(height: defaultPadding),
                if (widget.searchQueryModel.queryText != null)
                  Text(
                    "Search result for \"${widget.searchQueryModel.queryText}\"",
                    style: Theme.of(context).textTheme.titleMedium,
                  )
              ]),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(defaultPadding),
            sliver: searchResultBuild(),
          )
        ],
      ),
    );
  }

  Widget searchResultBuild() {
    if (searchResult != null) {
      if (searchResult!.isNotEmpty) {
        return SliverList.separated(
          itemCount: searchResult!.length,
          itemBuilder: (context, index) => PostsListTile(
            postModel: searchResult![index],
            // showAdFunction: () => interstitialAdController.showInteratialAd,
          ),
          separatorBuilder: (_, __) => const SizedBox(
            height: defaultPadding,
          ),
        );
      } else {
        return SliverList(
          delegate: SliverChildListDelegate.fixed([
            SizedBox(
              height: MediaQuery.of(context).size.width,
              child: const Center(child: Text("No Data Found!")),
            ),
          ]),
        );
      }
    } else {
      return SliverList(
        delegate: SliverChildListDelegate.fixed([
          SizedBox(
            height: MediaQuery.of(context).size.width,
            child: const Center(child: CircularProgressIndicator()),
          ),
        ]),
      );
    }
  }

  Future<void> search(SearchQueryModel? query) async {
    if (query == null) return;
    if (mounted) setState(() => searchResult = null);
    searchResult = await FirestoreService.searchFromQuery(query);
    if (mounted) setState(() {});
  }
}
