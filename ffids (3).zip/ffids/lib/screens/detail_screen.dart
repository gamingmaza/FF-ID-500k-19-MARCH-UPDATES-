// ignore_for_file: deprecated_member_use

import 'dart:developer';
import 'package:ffids_dark/main.dart';
import 'package:ffids_dark/modules/purchase/widgets/buy_button.dart';
import 'package:ffids_dark/providers/auth.dart';
import 'package:ffids_dark/services/auth_service.dart';
import 'package:ffids_dark/widgets/sliding_image_widget.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';
import 'package:waveui/waveui.dart';
import '../data/constants.dart';
import '../hive_models/favourite_posts.dart';
import '../models/post_model.dart';
import '../services/firestore_service.dart';
import '../utils/login_required_dialog.dart';
import '../widgets/contact_button.dart';
import '../widgets/my_submit_button.dart';
import 'chats/chat_room.dart';

class DetailScreen extends StatefulWidget {
  const DetailScreen({super.key, required this.postModel});

  final PostModel postModel;

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  final _buttonController = ContactButtonController();
  // RewardedAd rewardedAd = RewardedAd();
  // bool _isInterstitialAdLoaded = false;
  @override
  void initState() {
    super.initState();
    // rewardedAd.initializeListener();
  }

  // @override
  // void initState() {
  //   super.initState();
  //   _loadInterstitialAd();
  // }

  // _showInterstitialAd() async {
  //   if (_isInterstitialAdLoaded == true) {
  //     await FacebookInterstitialAd.showInterstitialAd();
  //   } else {
  //     log("Interstial Ad not yet loaded!");
  //   }
  // }

  // _loadInterstitialAd() async {
  //   log("Ads loading");
  //   await FacebookInterstitialAd.loadInterstitialAd(
  //       placementId: "2082563042104269_2082672058760034",
  //       listener: (result, value) {
  //         switch (result) {
  //           case InterstitialAdResult.ERROR:
  //             log("Error: $value");
  //             break;
  //           case InterstitialAdResult.LOADED:
  //             _isInterstitialAdLoaded = true;
  //             log("Loaded: $value");
  //             break;
  //           case InterstitialAdResult.CLICKED:
  //             log("Clicked: $value");
  //             break;
  //           case InterstitialAdResult.LOGGING_IMPRESSION:
  //             log("Logging Impression: $value");
  //             break;
  //           case InterstitialAdResult.DISPLAYED:
  //             log("Displayed: $value");
  //             break;
  //           case InterstitialAdResult.DISMISSED:
  //             log("Dismissed: $value");
  //             _isInterstitialAdLoaded = false;
  //             _loadInterstitialAd();
  //             break;
  //         }
  //         log(">> FAN > Interstitial Ad: $result --> $value");
  //       });
  // }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Provider.of<UserStateProvider>(context).currentUser,
      builder: (context, userSnapshot) {
        return Scaffold(
          appBar: AppBar(
            title: Text("Details"),
            centerTitle: true,
          ),
          body: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SlidingImageWidget(
                  postModel: widget.postModel,
                ),

                Padding(
                  padding: EdgeInsets.all(defaultPadding),
                  child: Text(
                    widget.postModel.title,
                    style: Theme.of(context).textTheme.headlineLarge,
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(defaultPadding),
                  child: Text(widget.postModel.description),
                ),
                const SizedBox(height: defaultPadding),

                //changes made by nasir   widget.postModel.boughtBy != null
                if (AuthService().user?.uid == widget.postModel.boughtBy &&
                    widget.postModel.boughtBy != null)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    child: SelectableText(
                      widget.postModel.account ?? "Please contact admin",
                      style: const WaveTextTheme(isDarkMode: false).bodyLarge,
                    ),
                  ),
                //Changes made by nasir && userSnapshot.data?.uid != null
                ((widget.postModel.authorId == userSnapshot.data?.uid) &&
                        userSnapshot.data?.uid != null)
                    ? Center(
                        child: MySubmitButton(
                          label: "Delete",
                          onPressed: () {
                            FirestoreService.deleteId(widget.postModel);
                            Navigator.pop(context);
                          },
                        ),
                      )
                    : const SizedBox(height: 64)
              ],
            ),
          ),
          floatingActionButtonLocation:
              FloatingActionButtonLocation.centerFloat,
          floatingActionButton: buildFloatingActionButton(userSnapshot.data),
        );
      },
    );
  }

  Widget? buildFloatingActionButton(User? currentUser) {
    if (widget.postModel.authorId == currentUser?.uid) {
      return null;
    } else {
      return Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          SizedBox.square(
            dimension: 64,
            child: Material(
              color: primaryColor,
              borderRadius: BorderRadius.circular(64),
              clipBehavior: Clip.hardEdge,
              child: AddPostToFavouriteButton(
                postModel: widget.postModel,
              ),
            ),
          ),
          ContactButton(
            controller: _buttonController,
            onPressed: () async {
              if (interstitialAdController.isAdLoaded) {
                interstitialAdController.show();
              } else {
                log("❌ Ad Not Loaded Yet");
              }
              if (currentUser != null) {
                _buttonController.startLoading();
                final docId = await FirestoreService.sellerChatDocId(
                  currentUser,
                  widget.postModel,
                );
                _buttonController.stopLoading();
                if (docId != null && mounted) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ChatRoom(
                        docId: docId,
                        anotherUserId: widget.postModel.authorId,
                        anotherUserName: widget.postModel.authorName,
                        anotherUserPhotoUrl: widget.postModel.authorPhoto,
                      ),
                    ),
                  );
                }
              } else {
                loginRequireDialog(context);
              }
            },
          ),
          AuthService().user?.uid != widget.postModel.boughtBy
              ? BuyButton(postModel: widget.postModel)
              : const SizedBox.shrink(),
        ],
      );
    }
  }
}

class AddPostToFavouriteButton extends StatelessWidget {
  const AddPostToFavouriteButton({super.key, required this.postModel});

  final PostModel postModel;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: Hive.box<FavouritePosts>('favourite_posts').listenable(),
      builder: (context, box, _) {
        bool isFavourite = box.containsKey(postModel.id);
        return InkWell(
          onTap: () => !isFavourite
              ? box.put(
                  postModel.id,
                  FavouritePosts(
                    postModel.id,
                    postModel.title,
                    postModel.thumbnail,
                    postModel.price,
                  ))
              : box.delete(postModel.id),
          child: Center(
            child: Icon(
              isFavourite
                  ? Icons.favorite_rounded
                  : Icons.favorite_outline_rounded,
              size: 32,
              color: Colors.white,
            ),
          ),
        );
      },
    );
  }
}
