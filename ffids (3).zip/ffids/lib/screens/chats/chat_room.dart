import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import '../../data/constants.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../../utils/show_alert.dart';
import '../../widgets/chat_bubble.dart';

class ChatRoom extends StatefulWidget {
  const ChatRoom({
    super.key,
    required this.docId,
    required this.anotherUserId,
    required this.anotherUserName,
    required this.anotherUserPhotoUrl,
    this.onDelete,
  });

  final String docId, anotherUserId, anotherUserName, anotherUserPhotoUrl;
  final Function? onDelete;

  @override
  State<ChatRoom> createState() => _ChatRoomState();
}

class _ChatRoomState extends State<ChatRoom> {
  final _currentUser = AuthService().user;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        leadingWidth: 24,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.keyboard_backspace_rounded),
        ),
        centerTitle: false,
        backgroundColor:
            Theme.of(context).scaffoldBackgroundColor.withOpacity(.95),
        actions: [
          IconButton(
            onPressed: () async {
              await FirestoreService.chats.doc(widget.docId).delete();
              if (mounted) Navigator.pop(context);
              widget.onDelete?.call();
            },
            icon: const Icon(Icons.delete),
            color: Colors.red,
          ),
        ],
        title: Row(
          children: [
            CircleAvatar(
              backgroundColor: Colors.transparent,
              backgroundImage: CachedNetworkImageProvider(
                widget.anotherUserPhotoUrl,
              ),
            ),
            const SizedBox(width: defaultPadding / 2),
            Expanded(
              child: Text(
                widget.anotherUserName,
                style: Theme.of(context).textTheme.titleMedium,
              ),
            ),
          ],
        ),
      ),
      body: StreamBuilder(
        stream: FirestoreService.chats.doc(widget.docId).snapshots(),
        builder: (context, snapshot) {
          if (snapshot.data != null && snapshot.data!.exists) {
            var messages = List<Map<String, dynamic>>.from(
                snapshot.data!.data()?['messages']);
            return Column(
              children: [
                Expanded(
                  child: messages.isEmpty
                      ? const Center(child: Text("No messages yet!"))
                      : ListView.builder(
                          itemCount: messages.length,
                          padding: const EdgeInsets.all(defaultPadding),
                          reverse: true,
                          itemBuilder: (context, index) {
                            return ChatBubble(
                              type: messages[index]['type'],
                              content: messages[index]['content'],
                              isAuthor: messages[index]['senderId'] ==
                                  _currentUser?.uid,
                            );
                          },
                        ),
                ),
                MessageTypingField(messages: messages, chatDocId: widget.docId)
              ],
            );
          } else if (snapshot.hasError) {
            return Column(
              children: [
                Expanded(child: Center(child: Text(snapshot.error.toString()))),
                MessageTypingField(),
              ],
            );
          } else {
            return Column(
              children: [
                const Expanded(
                  child: Center(child: CircularProgressIndicator()),
                ),
                MessageTypingField(),
              ],
            );
          }
        },
      ),
    );
  }
}

class MessageTypingField extends StatelessWidget {
  MessageTypingField({super.key, this.messages, this.chatDocId});

  final _messageController = TextEditingController();
  final List<Map<String, dynamic>>? messages;
  final String? chatDocId;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: _messageController,
      decoration: InputDecoration(
        hintText: "Enter message",
        filled: true,
        fillColor: Colors.white,
        suffixIcon: GestureDetector(
          onTap: () async {
            try {
              final text = _messageController.text.trim();
              if (text.isNotEmpty) {
                messages?.insert(0, {
                  'type': 'text',
                  'content': text,
                  'senderId': AuthService().user!.uid,
                });
                List<Map<String, dynamic>>? messagesList;
                if (messages != null && messages!.length > 300) {
                  messagesList = messages!.sublist(0, 300);
                }
                await FirestoreService.chats.doc(chatDocId).update({
                  'messages': messagesList ?? messages,
                  'lastMessage': text,
                  'date': Timestamp.now(),
                });
                _messageController.clear();
              }
            } catch (e) {
              showErrorAlert(
                message: e.runtimeType == String ? '$e' : '${e.runtimeType}',
              );
            }
          },
          child: Padding(
            padding: const EdgeInsets.all(defaultPadding / 2),
            child: Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: primaryColor.withOpacity(0.05),
                borderRadius: BorderRadius.circular(defaultBorderRadius),
              ),
              child: const Center(child: Icon(Icons.send_rounded)),
            ),
          ),
        ),
        border: outlineInputBorder,
        enabledBorder: outlineInputBorder,
        focusedBorder: outlineInputBorder,
        errorBorder: outlineInputBorder,
      ),
      style: const TextStyle(
        fontSize: 14,
        fontWeight: FontWeight.w500,
        height: 1.4,
      ),
      maxLines: 3,
      minLines: 1,
    );
  }
}

const OutlineInputBorder outlineInputBorder = OutlineInputBorder(
  borderRadius: BorderRadius.all(Radius.circular(12)),
  borderSide: BorderSide.none,
);
