import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import '../../data/constants.dart';
import '../../models/chat_model.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../../widgets/chat_tile.dart';

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});

  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.keyboard_backspace_rounded),
          ),
          title: Text(
            "Chats",
            style: Theme.of(context).textTheme.titleMedium,
          ),
          bottom: const TabBar(
            tabs: [Tab(text: "Buyers"), Tab(text: "Sellers")],
            indicatorColor: Colors.black12,
          ),
        ),
        body: const TabBarView(
          children: [
            ChatsListView(getBuyersList: true),
            ChatsListView(getBuyersList: false),
          ],
        ),
      ),
    );
  }
}

class ChatsListView extends StatefulWidget {
  const ChatsListView({super.key, required this.getBuyersList});

  final bool getBuyersList;

  @override
  State<ChatsListView> createState() => _ChatsListViewState();
}

class _ChatsListViewState extends State<ChatsListView> {
  final ScrollController _scrollController = ScrollController();
  int limit = 30;
  bool isLoading = false, hasMore = true;
  final currentUser = AuthService().user;
  DocumentSnapshot<Object?>? lastDoc;
  List<ChatModel> chatsList = [];

  @override
  void initState() {
    super.initState();
    fetchChats();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent - 100) {
      fetchChats();
    }
  }

  Future fetchChats() async {
    if (!hasMore || isLoading) return;
    setState(() => isLoading = true);

    try {
      if (currentUser != null) {
        var (chats, doc) = await FirestoreService.getChats(
          currentUser!.uid,
          widget.getBuyersList,
          limit,
          lastDoc,
        );
        if (chats.isNotEmpty) {
          setState(() {
            chatsList.addAll(chats);
            lastDoc = doc;
            hasMore = chats.length >= limit;
          });
        } else {
          setState(() => hasMore = false);
        }
      }
    } catch (e) {
      setState(() => hasMore = false);
    }
    setState(() => isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return isLoading && chatsList.isEmpty
        ? const Center(child: CircularProgressIndicator(strokeWidth: 3))
        : chatsList.isEmpty
            ? const Center(child: Text("No Messages"))
            : ListView.separated(
                key: const PageStorageKey('chats-list'),
                controller: _scrollController,
                padding: const EdgeInsets.all(defaultPadding),
                itemCount: chatsList.length + (hasMore ? 1 : 0),
                itemBuilder: (context, index) {
                  if (index < chatsList.length) {
                    return ChatTile(
                      chatModel: chatsList[index],
                      currentUser: currentUser!,
                      onDelete: () {
                        setState(() {
                          chatsList.clear();
                          lastDoc = null;
                          hasMore = true;
                        });
                        fetchChats();
                      },
                    );
                  } else {
                    return const Center(
                      child: Padding(
                        padding: EdgeInsets.all(8.0),
                        child: CircularProgressIndicator(strokeWidth: 3),
                      ),
                    );
                  }
                },
                separatorBuilder: (context, index) => const SizedBox(height: 8),
              );
  }

  SizedBox loadingIndicator() {
    fetchChats();
    return SizedBox(
      height: chatsList.isEmpty ? 0 : 64,
      child: chatsList.isEmpty
          ? null
          : Center(
              child: hasMore
                  ? const SizedBox.square(
                      dimension: 24,
                      child: CircularProgressIndicator(strokeWidth: 3),
                    )
                  : null,
            ),
    );
  }
}
