// ignore_for_file: deprecated_member_use

import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ffids_dark/providers/auth.dart';
import 'package:ffids_dark/widgets/posts_listtile.dart';
import 'package:ffids_dark/widgets/sliding_image_widget.dart';
import 'package:provider/provider.dart';
import 'package:waveui/waveui.dart';
import '../data/constants.dart';
import '../models/post_model.dart';

class BoughtAccountDetailPage extends StatefulWidget {
  const BoughtAccountDetailPage({
    super.key,
    required this.postModel,
    this.onRevert,
  });

  final PostModel postModel;
  final VoidCallback? onRevert;
  @override
  State<BoughtAccountDetailPage> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<BoughtAccountDetailPage> {
  late DateTime transactionDateTime;
  final double fontSize = 16;
  final double padding = 20;
  String formattedTransactionDate = "";
  @override
  void initState() {
    super.initState();
    try {
      log("ID:${widget.postModel.id}");
      transactionDateTime = DateTime.fromMillisecondsSinceEpoch(
          int.parse(widget.postModel.paymentResult?.transactionDate ?? ""));
      formattedTransactionDate = formatDateTime(transactionDateTime);
    } catch (e) {
      formattedTransactionDate = "N/A";
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder(
      stream: Provider.of<UserStateProvider>(context).currentUser,
      builder: (context, userSnapshot) {
        return Scaffold(
          appBar: AppBar(
            title: Text("Details"),
            centerTitle: true,
          ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SlidingImageWidget(
                postModel: widget.postModel,
              ),
              Padding(
                padding: EdgeInsets.all(defaultPadding),
                child: Text(
                  widget.postModel.title,
                  style: Theme.of(context).textTheme.headlineLarge,
                ),
              ),
              LabelValueText(
                  label: "Account",
                  padding: padding,
                  fontsize: fontSize,
                  value: widget.postModel.account ?? "N/A"),
              LabelValueText(
                  label: "Category",
                  padding: padding,
                  fontsize: fontSize,
                  value: widget.postModel.category),
              LabelValueText(
                  label: "Date",
                  fontsize: fontSize,
                  padding: padding,
                  value: formatTimestamp(widget.postModel.date)),
              LabelValueText(
                  label: "Name",
                  padding: padding,
                  fontsize: fontSize,
                  value: widget.postModel.paymentResult?.name ?? "N/A"),
              LabelValueText(
                  label: "User",
                  fontsize: fontSize,
                  padding: padding,
                  value: widget.postModel.paymentResult?.user ?? "N/A"),
              LabelValueText(
                  label: "Product ID",
                  padding: padding,
                  fontsize: fontSize,
                  value: widget.postModel.paymentResult?.productID ?? "N/A"),
              LabelValueText(
                  label: "Purchase ID",
                  fontsize: fontSize,
                  padding: padding,
                  value: widget.postModel.paymentResult?.purchaseId ?? "N/A"),
              LabelValueText(
                  label: "Transaction Date",
                  fontsize: fontSize,
                  padding: padding,
                  value: formattedTransactionDate),
              LabelValueText(
                  label: "UID",
                  fontsize: fontSize,
                  padding: padding,
                  value: widget.postModel.paymentResult?.uid ?? "N/A"),
              LabelValueText(
                  label: "Price",
                  fontsize: fontSize,
                  padding: padding,
                  value: widget.postModel.price.toString()),
              SizedBox(
                height: 12,
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: InkWell(
                  onTap: widget.onRevert,
                  child: Center(
                    child: Container(
                        width: 300,
                        padding:
                            EdgeInsets.symmetric(vertical: 10, horizontal: 40),
                        decoration: BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(25),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black45,
                              blurRadius: 6,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Center(
                            child: Text(
                          "Revert",
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16),
                        ))),
                  ),
                ),
              ),
              SizedBox(
                height: 8,
              ),
            ],
          ),
          // floatingActionButtonLocation:
          //     FloatingActionButtonLocation.centerFloat,
          // floatingActionButton: buildFloatingActionButton(userSnapshot.data),
        );
      },
    );
  }

  String formatTimestamp(Timestamp? timestamp) {
    if (timestamp == null) return "N/A"; // Handle null case

    DateTime dateTime = timestamp.toDate(); // Convert Timestamp to DateTime

    return "${dateTime.year}-${dateTime.month.toString().padLeft(2, '0')}-${dateTime.day.toString().padLeft(2, '0')} "
        "${dateTime.hour % 12 == 0 ? 12 : dateTime.hour % 12}:"
        "${dateTime.minute.toString().padLeft(2, '0')} "
        "${dateTime.hour >= 12 ? 'PM' : 'AM'}";
  }

  String formatDateTime(DateTime dateTime) {
    return "${dateTime.year}-${dateTime.month.toString().padLeft(2, '0')}-${dateTime.day.toString().padLeft(2, '0')} "
        "${dateTime.hour % 12 == 0 ? 12 : dateTime.hour % 12}:"
        "${dateTime.minute.toString().padLeft(2, '0')} "
        "${dateTime.hour >= 12 ? 'PM' : 'AM'}";
  }
}
