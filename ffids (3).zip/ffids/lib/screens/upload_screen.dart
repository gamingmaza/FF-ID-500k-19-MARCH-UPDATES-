import 'dart:developer';
import 'dart:io';

import 'package:chips_choice/chips_choice.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as img;
import 'package:uuid/uuid.dart';

import '../data/categories.dart';
import '../data/constants.dart';
import '../models/post_model.dart';
import '../services/auth_service.dart';
import '../services/firestore_service.dart';
import '../utils/show_alert.dart';
import '../utils/upload_image.dart';
import '../widgets/my_submit_button.dart';
import '../widgets/my_textfield.dart';
import 'detail_screen.dart';

enum UploadState {
  none,
  imageUploading,
  thumbnailCreation,
  additionalImageUploading,
  submitting
}

class UploadScreen extends StatefulWidget {
  const UploadScreen({super.key});

  @override
  State<UploadScreen> createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();
  final _accountController = TextEditingController();
  final _imagePicker = ImagePicker();
  final _currentUser = AuthService().user;

  XFile? _selectedScreenshot;
  List<XFile> _selectedImages = [];
  String _category = "";
  int otherUploadingImageId = 1;
  UploadState uploadState = UploadState.none;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.keyboard_backspace_rounded),
        ),
        title: Text(
          "Upload",
          style: Theme.of(context).textTheme.titleMedium,
        ),
      ),
      body: Center(
        child: uploadState == UploadState.none
            ? ListView(
                padding: const EdgeInsets.all(defaultPadding),
                shrinkWrap: true,
                children: [
                  MyTextField(
                    controller: _titleController,
                    hintText: "Title",
                    prefixIcon: const Icon(Icons.title_rounded),
                  ),
                  const SizedBox(height: defaultPadding),
                  MyTextField(
                    controller: _descriptionController,
                    hintText: "Description",
                    maxLines: 10,
                    prefixIcon: const Icon(Icons.edit_note_rounded),
                  ),
                  const SizedBox(height: defaultPadding),

                  // Screenshot Picker (Main Image)
                  _buildImagePicker(
                      "Select Main Image", pickScreenshot, _selectedScreenshot),

                  const SizedBox(height: defaultPadding),

                  // Multi Image Picker
                  _buildMultiImagePicker(),

                  const SizedBox(height: defaultPadding),
                  MyTextField(
                    controller: _priceController,
                    hintText: "Price (123.45)",
                    prefixIcon: const Icon(Icons.attach_money_rounded),
                    keyboardType: TextInputType.number,
                  ),
                  const SizedBox(height: defaultPadding),
                  MyTextField(
                    controller: _accountController,
                    hintText: "ID & Password",
                    maxLines: 2,
                    prefixIcon: const Icon(Icons.attach_email_outlined),
                  ),
                  const SizedBox(height: defaultPadding),
                  ChipsChoice.single(
                    value: _category,
                    choiceStyle: C2ChipStyle(
                      foregroundStyle: Theme.of(context).textTheme.labelLarge,
                      foregroundColor: primaryColor,
                      borderRadius: BorderRadius.circular(defaultBorderRadius),
                      height: 40,
                    ),
                    wrapped: true,
                    choiceCheckmark: true,
                    choiceItems: categories
                        .map((e) => C2Choice(value: e['tag'], label: e['name']))
                        .toList(),
                    onChanged: (v) => setState(() => _category = v),
                  ),
                  const SizedBox(height: defaultPadding * 2),
                  Center(
                    child: MySubmitButton(
                      label: "Upload",
                      onPressed: onUploadButtonPressed,
                    ),
                  ),
                ],
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(),
                  const SizedBox(height: defaultPadding),
                  Text(decideLoadingText(uploadState, otherUploadingImageId,
                      _selectedImages.length)),
                ],
              ),
      ),
    );
  }

  Widget _buildImagePicker(
      String label, VoidCallback onTap, XFile? selectedImage) {
    return SizedBox(
      height: MediaQuery.of(context).size.width / 2,
      child: Material(
        borderRadius: BorderRadius.circular(defaultPadding),
        color: Colors.white,
        clipBehavior: Clip.hardEdge,
        child: InkWell(
          onTap: onTap,
          child: selectedImage == null
              ? Center(child: Text(label))
              : Image.file(File(selectedImage.path), fit: BoxFit.cover),
        ),
      ),
    );
  }

  Widget _buildMultiImagePicker() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Select Additional Images:"),
        Wrap(
          spacing: 8.0,
          runSpacing: 8.0,
          children: _selectedImages
              .map((file) => Image.file(File(file.path),
                  width: 100, height: 100, fit: BoxFit.cover))
              .toList(),
        ),
        TextButton.icon(
          icon: const Icon(Icons.add_photo_alternate),
          label: const Text("Pick Images"),
          onPressed: pickMultipleImages,
        ),
      ],
    );
  }

  Future<void> pickScreenshot() async {
    _selectedScreenshot =
        await _imagePicker.pickImage(source: ImageSource.gallery);
    setState(() {});
  }

  Future<void> pickMultipleImages() async {
    final pickedImages = await _imagePicker.pickMultiImage();
    if (pickedImages.isNotEmpty) {
      setState(() {
        _selectedImages = pickedImages;
      });
    }
  }

  Future<void> onUploadButtonPressed() async {
    otherUploadingImageId = 1;
    if (_titleController.text.isEmpty || _titleController.text.length < 5) {
      showErrorAlert(message: "Enter a valid Title");
      return;
    }
    if (_selectedScreenshot == null) {
      showErrorAlert(message: "Select a main image");
      return;
    }

    setState(() => uploadState = UploadState.imageUploading);
    String uuid = const Uuid().v4().replaceAll('-', '');
    String? thumbnailUrl, imageUrl;
    List<String> otherImages = [];

    try {
      // Upload Main Image and Thumbnail
      final screenshotBytes = await _selectedScreenshot!.readAsBytes();
      img.Image? originalImage = img.decodeImage(screenshotBytes);
      if (originalImage == null) throw Exception("Thumbnail creation failed");

      img.Image thumbnail = img.copyResize(originalImage, width: 256);
      final thumbnailBytes = img.encodePng(thumbnail);

      imageUrl = await uploadImageToFirebase('CoverImages', screenshotBytes);
      thumbnailUrl = await uploadImageToFirebase('Thumbnails', thumbnailBytes);
      if (imageUrl == null || thumbnailUrl == null)
        throw Exception("Image Upload Failed!");
      setState(() => uploadState = UploadState.additionalImageUploading);
      // Upload Other Images
      for (var image in _selectedImages) {
        final bytes = await File(image.path).readAsBytes();
        final url = await uploadImageToFirebase('CoverImages', bytes);
        if (url != null) otherImages.add(url);
        log("Other image $otherUploadingImageId uploaded successfully");
        setState(() {
          otherUploadingImageId++;
        });
      }

      setState(() => uploadState = UploadState.submitting);

      final post = PostModel(
        id: uuid,
        thumbnail: thumbnailUrl,
        title: _titleController.text,
        description: _descriptionController.text,
        category: _category,
        authorId: _currentUser!.uid,
        imageUrl: imageUrl,
        otherImages: otherImages,
        price: double.parse(_priceController.text),
        account: _accountController.text,
        authorName: _currentUser?.displayName ?? '',
        authorPhoto: _currentUser?.photoURL ?? defaultProfilePhotoUrl,
      );

      await FirestoreService.uploadId(post);
      showSuccessAlert(message: "Upload Successful!");
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => DetailScreen(postModel: post)));
    } catch (e) {
      showErrorAlert(message: e.toString());
    }
  }

  String decideLoadingText(
      UploadState uploadState, int? imageId, int? totalImages) {
    if (uploadState == UploadState.imageUploading) {
      return "Uploading Images...";
    } else if (uploadState == UploadState.additionalImageUploading) {
      return "Uploading Additional Image $imageId/$totalImages";
    } else if (uploadState == UploadState.thumbnailCreation) {
      return "Creating Thumbnail...";
    } else {
      return "Submitting...";
    }
  }
}
