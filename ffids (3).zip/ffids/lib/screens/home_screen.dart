// ignore_for_file: deprecated_member_use

import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:ffids_dark/core/utils.dart';
import 'package:ffids_dark/data/firebase_banner_ad_info.dart';
import 'package:ffids_dark/inerstital_ad_admobd.dart';
import 'package:ffids_dark/main.dart';
import 'package:ffids_dark/services/firestore_service.dart';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:url_launcher/url_launcher.dart';

import '../data/constants.dart';
import '../data/posts_type.dart';
import '../services/auth_service.dart';
import '../utils/greeting_text.dart';
import '../utils/login_required_dialog.dart';
import '../widgets/home_categories_list.dart';
import '../widgets/drawer_view.dart';
import '../widgets/home_posts_list.dart';
import 'chats/chats.dart';
import 'upload_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return const Scaffold(body: Stack(children: [DrawerView(), HomeView()]));
  }
}

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> with WidgetsBindingObserver {
  FirestoreService firestoreService = FirestoreService();
  bool showAdOnEachPost = false;
  final _scrollController = ScrollController();
  final adController = InterstitialAdController();
  double xOffset = 0, yOffset = 0, scaleFactor = 1;
  bool isDrawerOpen = false;
  bool _showCustomBanner = false;
  FireBaseBannerAdInfo? fireBaseBannerAdInfo;

  @override
  void initState() {
    getValueFromKey().then((value) {
      setState(() {
        showAdOnEachPost = value;
      });
    });
    WidgetsBinding.instance.addObserver(this);
    appOpenAdManager.loadAd(
      (ad) {
        log("onAddLoaded Callback Called");
        ad.show();
      },
    );
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
      (timeStamp) {
        firestoreService.getShowAdValue().then(
          (value) {
            try {
              setState(() {
                _showCustomBanner = value ?? false;
              });
            } catch (e) {
              log(e.toString());
            }
          },
        );
        firestoreService.fetchBannerAd().then(
          (value) {
            try {
              setState(() {
                fireBaseBannerAdInfo = value;
              });
            } catch (e) {
              log(e.toString());
            }
          },
        );
      },
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this); // Remove observer
    super.dispose();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    try {
      firestoreService.getShowAdValue().then(
        (value) {
          if (value != null) {
            setState(() {
              _showCustomBanner = value;
            });
          }
        },
      );
    } catch (e) {}
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return PopScope(
      canPop: !isDrawerOpen,
      onPopInvoked: (_) => hideDrawer(),
      child: GestureDetector(
        onTap: () => isDrawerOpen ? hideDrawer() : null,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          transform: Matrix4.translationValues(xOffset, yOffset, 0)
            ..scale(scaleFactor),
          decoration: BoxDecoration(
            borderRadius: isDrawerOpen
                ? BorderRadius.circular(defaultBorderRadius * 2)
                : null,
            boxShadow: isDrawerOpen
                ? const [BoxShadow(color: Colors.black12, blurRadius: 24)]
                : null,
          ),
          clipBehavior: Clip.hardEdge,
          child: Scaffold(
            appBar: AppBar(
              leading: IconButton(
                onPressed: () => isDrawerOpen ? hideDrawer() : showDrawer(),
                icon: isDrawerOpen
                    ? const Icon(Icons.keyboard_backspace_rounded)
                    : SvgPicture.asset("assets/svg/menu.svg"),
              ),
              title: Text(getGreetingText(), style: textTheme.titleSmall),
              actions: [
                // IconButton(
                //   icon: SvgPicture.asset("assets/svg/Notification.svg"),
                //   onPressed: () {
                //     Navigator.push(context, MaterialPageRoute(
                //       builder: (context) {
                //         return const NotificationScreen();
                //       },
                //     ));
                //   },
                // ),
                IconButton(
                  icon: const ImageIcon(AssetImage('assets/images/chat.png')),
                  onPressed: () {
                    adController.show();
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ChatsScreen()),
                    );
                  },
                ),
              ],
            ),
            body: Stack(
              children: [
                SingleChildScrollView(
                  controller: _scrollController,
                  physics: BouncingScrollPhysics(),
                  child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Explore", style: textTheme.headlineLarge),
                        Text(
                          "The best gaming id's for you",
                          style: textTheme.headlineSmall,
                        ),
                        //Banner AD
                        // const SizedBox(height: 16),
                        // const AdMobInlineBannerAd(
                        //   size: AdMobInlineBannerType.small,
                        // ),
                        // const SizedBox(height: 16),
                        // const BannerAds(),
                        //Search Widget
                        // Padding(
                        //   padding:
                        //       const EdgeInsets.symmetric(vertical: defaultPadding),
                        //   child: SearchForm(
                        //     onSearch: (queryModel) => Navigator.push(
                        //       context,
                        //       MaterialPageRoute(
                        //         builder: (context) =>
                        //             SearchScreen(searchQueryModel: queryModel),
                        //       ),
                        //     ),
                        //   ),
                        // ),
                        const SizedBox(height: 8),
                        if (_showCustomBanner && fireBaseBannerAdInfo != null)
                          InkWell(
                            onTap: () {
                              _launchUrl(fireBaseBannerAdInfo?.adUrl ?? "");
                            },
                            child: Padding(
                              padding: EdgeInsets.only(right: 0),
                              child: SizedBox(
                                height: fireBaseBannerAdInfo?.height ?? 220,
                                child: CachedNetworkImage(
                                  errorWidget: (context, url, error) =>
                                      SizedBox.shrink(),
                                  imageUrl: fireBaseBannerAdInfo!.imageUrl,
                                  fit: BoxFit.contain,
                                ),
                              ),
                            ),
                          ),
                        const SizedBox(height: 12),
                        // Horizontally Scrollable Items After Search Bar
                        const HomeCategoriesList(), const SizedBox(height: 8),
                        HomePostsList(
                          title: "New Posts",
                          postsType: PostsType.latest,
                          // showInertialAd: interstitialAdController.showInteratialAd,
                        ),
                        // const HomePostsList(
                        //   title: "Popular",
                        //   postsType: PostsType.popular,
                        //   // showInertialAd: interstitialAdController.showInteratialAd,
                        // ),
                      ],
                    ),
                  ),
                ),
                Positioned(
                  bottom: 10,
                  right: 10,
                  child: Column(
                    children: [
                      // Text(
                      //   "Scroll for more",
                      //   style: TextStyle(
                      //     fontSize: 14,
                      //     fontWeight: FontWeight.bold,
                      //     color: Colors.black54,
                      //   ),
                      // ),
                      (AuthService().user?.email ==
                                  "ahreftooltechonway@gmail.com" ||
                              AuthService().user?.email ==
                                  "codewithmnasir@gmail.com")
                          ? Container()
                          : AnimatedOpacity(
                              opacity: 1.0,
                              duration: Duration(seconds: 1),
                              child: Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.black.withOpacity(0.6),
                                ),
                                child: Center(
                                  child: IconButton(
                                    icon: Icon(
                                      Icons.keyboard_arrow_down_rounded,
                                      color: Colors.white,
                                      size: 30,
                                    ),
                                    onPressed: () {
                                      if (_scrollController.hasClients) {
                                        _scrollController.animateTo(
                                          _scrollController.offset +
                                              300, // Scrolls down by 100 pixels
                                          duration: Duration(
                                              milliseconds:
                                                  300), // Smooth animation
                                          curve: Curves.easeInOut,
                                        );
                                      }
                                    },
                                  ),
                                ),
                              ),
                            ),
                    ],
                  ),
                ),
              ],
            ),
            // body: SingleChildScrollView(
            //   controller: _scrollController,
            //   physics: const BouncingScrollPhysics(),
            //   padding: const EdgeInsets.all(defaultPadding),
            //   child: Column(
            //     crossAxisAlignment: CrossAxisAlignment.start,
            //     children: [
            //       Text("Explore", style: textTheme.headlineLarge),
            //       Text(
            //         "The best gaming id's for you",
            //         style: textTheme.headlineSmall,
            //       ),
            //       //Banner AD
            //       // const SizedBox(height: 16),
            //       // const AdMobInlineBannerAd(
            //       //   size: AdMobInlineBannerType.small,
            //       // ),
            //       const SizedBox(height: 16),
            //       // const BannerAds(),
            //       //Search Widget
            //       Padding(
            //         padding:
            //             const EdgeInsets.symmetric(vertical: defaultPadding),
            //         child: SearchForm(
            //           onSearch: (queryModel) => Navigator.push(
            //             context,
            //             MaterialPageRoute(
            //               builder: (context) =>
            //                   SearchScreen(searchQueryModel: queryModel),
            //             ),
            //           ),
            //         ),
            //       ),
            //       // Horizontally Scrollable Items After Search Bar
            //       const HomeCategoriesList(),
            //       const HomePostsList(
            //         title: "New Posts",
            //         postsType: PostsType.latest,
            //         // showInertialAd: interstitialAdController.showInteratialAd,
            //       ),
            //       // const HomePostsList(
            //       //   title: "Popular",
            //       //   postsType: PostsType.popular,
            //       //   // showInertialAd: interstitialAdController.showInteratialAd,
            //       // ),
            //       const SizedBox(height: defaultPadding * 4),
            //     ],
            //   ),
            // ),
            floatingActionButton:
                // (AuthService().user!.email == "ahreftooltechonway@gmail.com" ||
                (AuthService().user?.email == "ahreftooltechonway@gmail.com" ||
                        AuthService().user?.email == "codewithmnasir@gmail.com")
                    ? FloatingActionButton.extended(
                        onPressed: () {
                          if (AuthService().user == null) {
                            loginRequireDialog(context);
                          } else {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => const UploadScreen()),
                            );
                          }
                        },
                        icon: const Icon(Icons.add_rounded),
                        label: const Text("Add Post"),
                      )
                    : null,
          ),
        ),
      ),
    );
  }

  showDrawer() {
    Size deviceSize = MediaQuery.of(context).size;
    xOffset = deviceSize.width * 0.6;
    yOffset = ((deviceSize.height - (deviceSize.height * 0.7)) / 2) + 18;
    // 18 is because of drawer has user info size of 72
    scaleFactor = 0.7;
    isDrawerOpen = true;
    setState(() {});
  }

  hideDrawer() {
    xOffset = yOffset = 0;
    scaleFactor = 1;
    isDrawerOpen = false;
    firestoreService.getShowAdValue().then(
      (value) {
        try {
          if (value != null) {
            setState(() {
              _showCustomBanner = value;
            });
          }
        } catch (e) {
          log(e.toString());
        }
      },
    );
    firestoreService.fetchBannerAd().then(
      (value) {
        try {
          if (value != null) {
            setState(() {
              fireBaseBannerAdInfo = value;
            });
          }
        } catch (e) {
          log(e.toString());
        }
      },
    );
    setState(() {});
  }

  bool _hasResumedFromBackground =
      false; // Track if the app was backgrounded manually
  bool _isShowingAd = false; // Track if an ad is currently being shown

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      log("✅ App resumed: User returned to the app!");

      // Only show ad if the user manually sent the app to the background
      if (_hasResumedFromBackground) {
        _hasResumedFromBackground = false; // Reset flag after showing ad

        appOpenAdManager.loadAd((ad) {
          log("🎬 Ad loaded and will be shown");
          _isShowingAd = true; // Set flag before showing ad
          ad.show();
          ad.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) {
              log("🚀 Ad closed");
              _isShowingAd = false; // Reset flag after ad is closed
            },
          );
        });
      }
    } else if (state == AppLifecycleState.paused) {
      log("⏸️ App paused: User left the app!");

      if (!_isShowingAd) {
        _hasResumedFromBackground =
            true; // Only set flag if app was backgrounded manually
      }
    }
  }
}

Future<void> _launchUrl(String url) async {
  if (!await launchUrl(Uri.parse(url))) {
    Fluttertoast.showToast(msg: "Can't launch url: $url");
  }
}
