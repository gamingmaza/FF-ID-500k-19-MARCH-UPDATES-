import 'dart:developer';
import 'dart:io';
import 'package:ffids_dark/services/firestore_service.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class UploadBannerAdInfo extends StatefulWidget {
  const UploadBannerAdInfo({super.key});

  @override
  State<UploadBannerAdInfo> createState() => _UploadBannerAdInfoState();
}

class _UploadBannerAdInfoState extends State<UploadBannerAdInfo> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback(
      (timeStamp) {
        firestoreService.getShowAdValue().then(
          (value) {
            try {
              setState(() {
                _showAd = value ?? false;
                _isLoading = false;
              });
            } catch (e) {
              _isLoading = false;
            }
          },
        );
      },
    );
  }

  FirestoreService firestoreService = FirestoreService();
  bool _showAd = false;
  bool _isLoading = true;
  final _formKey = GlobalKey<FormState>();
  bool isLoading = false;
  File? _selectedImage;
  final TextEditingController _linkController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();

  /// Function to pick an image
  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  /// Function to validate and submit
  void _submitForm() async {
    if (_formKey.currentState!.validate() && _selectedImage != null) {
      String link = _linkController.text.trim();
      double height = double.parse(_heightController.text.trim());
      setState(() {
        isLoading = true;
      });
      var result = await firestoreService.uploadBannerAd(
          imageFile: _selectedImage!,
          adUrl: link,
          height: height > 220 ? 220 : height);
      setState(() {
        isLoading = false;
      });
      if (result) Navigator.of(context).pop();

      // You can call your upload function here.
    } else {
      setState(() {
        isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please select an image and fill all fields")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Upload Banner Ad Info"),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Image Picker Button & Preview
              GestureDetector(
                onTap: _pickImage,
                child: Container(
                  height: 150,
                  decoration: BoxDecoration(
                    border: Border.all(color: Colors.grey),
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.grey[200],
                  ),
                  child: _selectedImage != null
                      ? Image.file(_selectedImage!, fit: BoxFit.cover)
                      : Center(child: Text("Tap to pick an image")),
                ),
              ),
              const SizedBox(height: 15),

              // Ad Link Input
              TextFormField(
                controller: _linkController,
                decoration: InputDecoration(
                  labelText: "Ad Link",
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.url,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return "Please enter a valid URL";
                  }

                  return null;
                },
              ),
              const SizedBox(height: 15),

              // Height Input
              TextFormField(
                controller: _heightController,
                decoration: InputDecoration(
                  labelText: "Ad Height",
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return "Height cannot be empty";
                  }
                  if (double.tryParse(value) == null) {
                    return "Enter a valid number";
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),

              // Submit Button
              isLoading
                  ? Center(
                      child: CircularProgressIndicator(),
                    )
                  : ElevatedButton(
                      onPressed: _submitForm,
                      child: const Text("Upload Ad"),
                    ),
              SizedBox(
                height: 20,
              ),
              _isLoading
                  ? Center(child: CircularProgressIndicator())
                  : GestureDetector(
                      onTap: _toggleShowAd,
                      child: AnimatedContainer(
                        duration: Duration(milliseconds: 300),
                        height: 50,
                        width: 150,
                        decoration: BoxDecoration(
                          color: _showAd ? Colors.green : Colors.red,
                          borderRadius: BorderRadius.circular(25),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black45,
                              blurRadius: 6,
                              offset: Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              _showAd ? Icons.check_circle : Icons.cancel,
                              color: Colors.white,
                            ),
                            SizedBox(width: 8),
                            Text(
                              _showAd ? "Enabled" : "Disabled",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
            ],
          ),
        ),
      ),
    );
  } // Toggle 'showAd' value in Firebase

  Future<void> _toggleShowAd() async {
    setState(() => _isLoading = true);
    try {
      final result = await firestoreService.toggleShowAd();
      setState(() {
        if (result) _showAd = !_showAd;
        _isLoading = false;
      });
    } catch (e) {
      log("Error toggling showAd: $e");
    }
  }
}
