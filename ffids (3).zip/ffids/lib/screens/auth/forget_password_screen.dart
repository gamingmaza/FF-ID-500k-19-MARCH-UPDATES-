import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../../data/constants.dart';
import '../../services/auth_service.dart';
import '../../utils/show_alert.dart';
import '../../widgets/my_submit_button.dart';
import '../../widgets/my_textfield.dart';

class ForgetPasswordScreen extends StatefulWidget {
  const ForgetPasswordScreen({super.key});

  @override
  State<ForgetPasswordScreen> createState() => _ForgetPasswordScreenState();
}

class _ForgetPasswordScreenState extends State<ForgetPasswordScreen> {
  final TextEditingController _emailController = TextEditingController();
  final _submitButtonController = MySubmitButtonController();

  bool emailSent = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: emailSent
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(defaultPadding * 3),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      "Email Send Successfully",
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: defaultPadding),
                    const Text(
                      "Open your inbox and check the password reset link.",
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: defaultPadding),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.4,
                      height: 48,
                      child: Material(
                        color: primaryColor,
                        borderRadius: BorderRadius.circular(64),
                        clipBehavior: Clip.hardEdge,
                        child: InkWell(
                          onTap: () => Navigator.pop(context),
                          child: const Center(
                            child: Text(
                              "Okay",
                              style: TextStyle(
                                fontWeight: FontWeight.w500,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            )
          : SingleChildScrollView(
              padding: const EdgeInsets.all(defaultPadding),
              child: Column(
                children: [
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.3,
                    child: Align(
                      alignment: Alignment.bottomCenter,
                      child: Text(
                        "Forgot Password?",
                        style: Theme.of(context).textTheme.headlineMedium,
                      ),
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.all(defaultPadding),
                    child: Text(
                      "A link will be sent to you via email to reset your password. You can change your account password from that link.",
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(height: defaultPadding * 2),
                  Form(
                    child: Column(
                      children: [
                        MyTextField(
                          controller: _emailController,
                          hintText: "Email",
                          prefixIcon: const Icon(Icons.email),
                        ),
                        const SizedBox(height: defaultPadding),
                        MySubmitButton(
                          label: "Submit",
                          controller: _submitButtonController,
                          onPressed: onSubmit,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: defaultPadding * 3),
                  Text.rich(
                    TextSpan(
                      text: "Try Again? ",
                      children: [
                        TextSpan(
                          text: "Login",
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: primaryColor,
                          ),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () => Navigator.pop(context),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Future<void> onSubmit() async {
    FocusManager.instance.primaryFocus?.unfocus();
    try {
      _submitButtonController.startLoading();
      final success = await AuthService.forgotPassword(_emailController.text);
      if (success) setState(() => emailSent = true);
      _submitButtonController.stopLoading();
    } on FirebaseAuthException catch (e) {
      showErrorAlert(
        message: e.runtimeType == String ? "$e" : "${e.runtimeType}",
      );
    }
  }
}
