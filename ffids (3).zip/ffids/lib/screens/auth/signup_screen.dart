import 'dart:developer';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../data/constants.dart';
import '../../services/auth_service.dart';
import '../../services/firestore_service.dart';
import '../../utils/show_alert.dart';
import '../../widgets/my_submit_button.dart';
import '../../widgets/my_textfield.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final _signUpButtonController = MySubmitButtonController();

  bool passwordHidden = true, termsAccepted = false;

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (_) => pushToLogin(),
      child: Scaffold(
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(defaultPadding),
          child: Column(
            children: [
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.3,
                child: Align(
                  alignment: const Alignment(0, 0.5),
                  child: Text(
                    "Sign Up",
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                ),
              ),
              Form(
                child: Column(
                  children: [
                    MyTextField(
                      controller: _nameController,
                      hintText: "Name",
                      prefixIcon: const Icon(Icons.person),
                    ),
                    const SizedBox(height: defaultPadding),
                    MyTextField(
                      controller: _emailController,
                      hintText: "Email",
                      prefixIcon: const Icon(Icons.email),
                    ),
                    const SizedBox(height: defaultPadding),
                    MyTextField(
                      controller: _passwordController,
                      hintText: "Password",
                      obsecureText: passwordHidden,
                      prefixIcon: const Icon(Icons.lock),
                      suffixIcon: GestureDetector(
                        onTap: () =>
                            setState(() => passwordHidden = !passwordHidden),
                        child: Icon(
                          passwordHidden
                              ? Icons.visibility_rounded
                              : Icons.visibility_off_rounded,
                        ),
                      ),
                    ),
                    const SizedBox(height: defaultPadding),
                    Row(
                      children: [
                        SizedBox(
                          height: 32,
                          child: Checkbox(
                            value: termsAccepted,
                            onChanged: (v) => setState(() {
                              termsAccepted = v ?? false;
                            }),
                            activeColor: primaryColor,
                          ),
                        ),
                        Expanded(
                          child: Text.rich(
                            TextSpan(
                              text: "I accept all the ",
                              children: [
                                TextSpan(
                                  text: "Terms & Conditions",
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: primaryColor,
                                  ),
                                  recognizer: TapGestureRecognizer()
                                    ..onTap = () => launchUrlString(termsUrl),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: defaultPadding),
                    MySubmitButton(
                      label: "Sign Up",
                      controller: _signUpButtonController,
                      onPressed: signUpButtonPressed,
                    ),
                  ],
                ),
              ),
              const SizedBox(height: defaultPadding * 3),
              Text.rich(
                TextSpan(
                  text: "Don't have an account? ",
                  children: [
                    TextSpan(
                      text: "Login",
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        color: primaryColor,
                      ),
                      recognizer: TapGestureRecognizer()
                        ..onTap = () => pushToLogin(),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> signUpButtonPressed() async {
    FocusManager.instance.primaryFocus?.unfocus();

    if (!termsAccepted) {
      showErrorAlert(message: "Accept the Terms & Conditions");
      return;
    }

    _signUpButtonController.startLoading();

    try {
      final user = await AuthService.signUp(
        _nameController.text,
        _emailController.text,
        _passwordController.text,
      );

      if (user != null && mounted) {
        try {
          await FirestoreService.createUserDatabase(user);
          Navigator.pushReplacementNamed(context, '/');
        } catch (e) {
          log("Firestore error: $e");
          showErrorAlert(
              message: "Failed to save user data. Please try again.");
        }
      }
    } catch (e) {
      log("Sign-up error: $e");
      showErrorAlert(message: "Sign-up failed. Please check your credentials.");
    } finally {
      _signUpButtonController.stopLoading();
    }
  }

  Future pushToLogin() => Navigator.pushReplacementNamed(context, '/');
}
