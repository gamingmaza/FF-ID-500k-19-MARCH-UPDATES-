import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../../data/constants.dart';
import '../../services/auth_service.dart';
import '../../widgets/continue_with_google_button.dart';
import '../../widgets/my_submit_button.dart';
import '../../widgets/my_textfield.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final _loginButtonController = MySubmitButtonController();

  bool passwordHidden = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(defaultPadding),
        child: Column(
          children: [
            Stack(
              children: [
                Positioned(
                  top: MediaQuery.of(context).padding.top,
                  right: 0,
                  child: GestureDetector(
                    onTap: () => Navigator.pushNamed(context, '/home'),
                    child: Text(
                      "Skip >>",
                      style: Theme.of(context).textTheme.labelLarge,
                    ),
                  ),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.3,
                  child: Align(
                    alignment: const Alignment(0, 0.5),
                    child: Text(
                      "Login",
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                  ),
                ),
              ],
            ),
            Form(
              child: Column(
                children: [
                  MyTextField(
                    controller: _emailController,
                    hintText: "Email",
                    prefixIcon: const Icon(Icons.email),
                  ),
                  const SizedBox(height: defaultPadding),
                  MyTextField(
                    controller: _passwordController,
                    hintText: "Password",
                    obsecureText: passwordHidden,
                    prefixIcon: const Icon(Icons.lock),
                    suffixIcon: GestureDetector(
                      onTap: () =>
                          setState(() => passwordHidden = !passwordHidden),
                      child: Icon(
                        passwordHidden
                            ? Icons.visibility_rounded
                            : Icons.visibility_off_rounded,
                      ),
                    ),
                  ),
                  const SizedBox(height: defaultPadding),
                  Align(
                    alignment: Alignment.centerRight,
                    child: GestureDetector(
                      onTap: () =>
                          Navigator.pushNamed(context, '/forget-password'),
                      child: Text(
                        "Forgot password?",
                        style: Theme.of(context)
                            .textTheme
                            .bodyMedium
                            ?.copyWith(fontWeight: FontWeight.w500),
                      ),
                    ),
                  ),
                  const SizedBox(height: defaultPadding),
                  MySubmitButton(
                    label: "Login",
                    controller: _loginButtonController,
                    onPressed: loginButtonPressed,
                  ),
                  const SizedBox(height: defaultPadding * 2),
                  Text.rich(
                    TextSpan(
                      text: "Don't have an account? ",
                      children: [
                        TextSpan(
                          text: "Sign Up",
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: primaryColor,
                          ),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () => Navigator.pushReplacementNamed(
                                context, '/signup'),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: defaultPadding * 2),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const SizedBox(width: defaultPadding * 2),
                const Expanded(child: Divider()),
                const SizedBox(width: defaultPadding),
                Text(
                  "Or",
                  style: TextStyle(color: Theme.of(context).dividerColor),
                ),
                const SizedBox(width: defaultPadding),
                const Expanded(child: Divider()),
                const SizedBox(width: defaultPadding * 2),
              ],
            ),
            const SizedBox(height: defaultPadding * 2),
            const ContinueWithGoogleButton(),
            const SizedBox(height: defaultPadding),
            Text.rich(
              TextSpan(
                text: "By continuing, you accept our all the ",
                children: [
                  TextSpan(
                    text: "Terms & Conditions",
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: primaryColor,
                    ),
                    recognizer: TapGestureRecognizer()
                      ..onTap = () => launchUrlString(termsUrl),
                  ),
                ],
                style: const TextStyle(fontSize: 10),
              ),
            ),
            const SizedBox(height: defaultPadding * 2),
          ],
        ),
      ),
    );
  }

  Future<void> loginButtonPressed() async {
    FocusManager.instance.primaryFocus?.unfocus();
    _loginButtonController.startLoading();
    await AuthService.login(_emailController.text, _passwordController.text);
    _loginButtonController.stopLoading();
  }
}
