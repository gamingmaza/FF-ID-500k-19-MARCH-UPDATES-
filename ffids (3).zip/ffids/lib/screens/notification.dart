// import 'package:flutter/material.dart';

// import '../data/constants.dart';

// class NotificationScreen extends StatelessWidget {
//   const NotificationScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         leading: IconButton(
//           onPressed: () => Navigator.pop(context),
//           icon: const Icon(Icons.keyboard_backspace_rounded),
//         ),
//         title: Text(
//           "Notifications",
//           style: Theme.of(context).textTheme.titleMedium,
//         ),
//       ),
//       body: ListView.separated(
//         itemCount: 10,
//         padding: const EdgeInsets.all(defaultPadding),
//         itemBuilder: (context, index) => InkWell(
//           onTap: () {},
//           borderRadius: BorderRadius.circular(defaultBorderRadius),
//           child: SizedBox(
//             height: 64,
//             child: Padding(
//               padding: const EdgeInsets.all(defaultPadding / 2),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Text(
//                     "Nofication Title",
//                     style: Theme.of(context).textTheme.labelLarge,
//                   ),
//                   const SizedBox(height: defaultPadding / 2),
//                   Text(
//                     "Nofication Title",
//                     style: Theme.of(context).textTheme.labelSmall,
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//         separatorBuilder: (context, index) => Divider(),
//       ),
//     );
//   }
// }
