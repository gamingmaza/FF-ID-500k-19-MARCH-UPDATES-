import 'package:cached_network_image/cached_network_image.dart';
import 'package:ffids_dark/extentions/my_num.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

import '../data/constants.dart';
import '../hive_models/favourite_posts.dart';
import '../services/firestore_service.dart';
import 'detail_screen.dart';

class FavouritePostsScreen extends StatefulWidget {
  const FavouritePostsScreen({super.key});

  @override
  State<FavouritePostsScreen> createState() => _FavouritePostsScreenState();
}

class _FavouritePostsScreenState extends State<FavouritePostsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.keyboard_backspace_rounded),
        ),
        title: Text(
          "Favourites Ids",
          style: Theme.of(context).textTheme.titleMedium,
        ),
      ),
      body: ValueListenableBuilder(
        valueListenable:
            Hive.box<FavouritePosts>('favourite_posts').listenable(),
        builder: (context, box, _) {
          if (box.values.isEmpty) {
            return const Center(child: Text("No Favourite Ids"));
          } else {
            return ListView.builder(
              key: const PageStorageKey('favourite-posts-list'),
              padding: const EdgeInsets.all(defaultPadding),
              itemCount: box.values.length,
              itemBuilder: (context, index) {
                var post = box.getAt(index)!;
                return FavouritePostListTile(post: post);
              },
            );
          }
        },
      ),
    );
  }
}

class FavouritePostListTile extends StatefulWidget {
  const FavouritePostListTile({super.key, required this.post});

  final FavouritePosts post;

  @override
  State<FavouritePostListTile> createState() => _FavouritePostListTileState();
}

class _FavouritePostListTileState extends State<FavouritePostListTile> {
  bool _isLoading = false;
  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(defaultBorderRadius),
      clipBehavior: Clip.hardEdge,
      child: InkWell(
        onTap: () async {
          if (_isLoading) return;
          setState(() => _isLoading = true);
          final postModel =
              await FirestoreService.fetchPostDetailsById(widget.post.docId);
          setState(() => _isLoading = false);
          if (postModel != null && mounted) {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => DetailScreen(
                  postModel: postModel,
                ),
              ),
            );
          }
        },
        child: Padding(
          padding: const EdgeInsets.all(defaultPadding),
          child: SizedBox(
            height: 94,
            child: _isLoading
                ? const Center(child: Text('Loading...'))
                : Row(
                    children: [
                      AspectRatio(
                        aspectRatio: 16 / 9,
                        child: ClipRRect(
                          borderRadius:
                              BorderRadius.circular(defaultBorderRadius),
                          child: CachedNetworkImage(
                            imageUrl: widget.post.imageUrl,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      const SizedBox(width: defaultPadding / 2),
                      Expanded(
                        child: Column(
                          children: [
                            Expanded(
                              child: Center(
                                child: Text(
                                  widget.post.title,
                                  maxLines: 3,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.centerRight,
                              child: Text(
                                "\$${widget.post.price.priceFormat()}",
                                style: textTheme.titleSmall,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}
