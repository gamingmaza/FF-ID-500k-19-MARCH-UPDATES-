import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ffids_dark/widgets/home_posts_list.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../data/constants.dart';
import '../data/posts_type.dart';
import '../models/post_model.dart';
import '../services/firestore_service.dart';
import '../widgets/posts_listtile.dart';

class PostsScreen extends StatefulWidget {
  final CollectionReference<Map<String, dynamic>>? reference;
  final bool isApprovePage;
  const PostsScreen({
    super.key,
    required this.postsType,
    this.reference,
    this.isApprovePage = false,
  });

  final PostsType postsType;

  @override
  State<PostsScreen> createState() => _PostsScreenState();
}

class _PostsScreenState extends State<PostsScreen> {
  late FirebaseFirestore firestore;
  int page = 1, limit = 10;
  bool isLoading = false, hasMore = true;
  DocumentSnapshot<Object?>? lastDoc;
  List<dynamic> displayItems = [];
  List<int> adPattern = [3, 5, 7, 5, 5];

  @override
  void initState() {
    super.initState();
    firestore = FirebaseFirestore.instance;
    fetchPosts();
  }

  Future<void> fetchPosts() async {
    if (!hasMore || isLoading) return;
    isLoading = true;
    try {
      var (posts, doc) = await FirestoreService.fetchPostsByType(
        widget.postsType,
        lastDoc,
        null,
        widget.reference,
      );
      if (posts != null) {
        lastDoc = doc;
        hasMore = posts.length >= limit;
        insertAds(posts);
      }
    } catch (e) {
      hasMore = false;
    }
    isLoading = false;
    if (mounted) setState(() {});
  }

  void insertAds(List<PostModel> posts) {
    List<dynamic> newDisplayItems = [];
    int index = 0, patternIndex = 0;

    while (index < posts.length) {
      int interval =
          (patternIndex < adPattern.length) ? adPattern[patternIndex] : 5;
      int endIndex = (index + interval).clamp(0, posts.length);

      newDisplayItems.addAll(posts.sublist(index, endIndex));
      index = endIndex;
      patternIndex++;

      // Insert ads **only** if it's not an approval page
      if (index < posts.length && !widget.isApprovePage) {
        newDisplayItems.add(const BannerAdWidget()); // Add Ad Widget
      }
    }

    displayItems.addAll(newDisplayItems);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.keyboard_backspace_rounded),
        ),
        title: Text(
          decideTitleText(widget.postsType),
          style: Theme.of(context).textTheme.titleMedium,
        ),
      ),
      body: isLoading && displayItems.isEmpty
          ? const Center(child: CircularProgressIndicator(strokeWidth: 3))
          : displayItems.isEmpty
              ? const Center(child: Text("No Posts Found"))
              : ListView.separated(
                  key: const PageStorageKey('posts-list'),
                  padding: const EdgeInsets.all(defaultPadding),
                  itemCount: displayItems.length + 1,
                  itemBuilder: (context, index) {
                    if (index < displayItems.length) {
                      var item = displayItems[index];
                      if (item is PostModel) {
                        return PostsListTile(
                          postModel: item,
                          isAdminView: widget.isApprovePage,
                          onApprove: () => widget.isApprovePage
                              ? approvePurchase(item)
                              : null,
                          onReject: () => widget.isApprovePage
                              ? rejectPurchase(item)
                              : null,
                          onRevert: () =>
                              widget.isApprovePage ? revertProduct(item) : null,
                        );
                      } else {
                        return item;
                      }
                    } else {
                      return loadingIndicator();
                    }
                  },
                  separatorBuilder: (context, index) =>
                      const SizedBox(height: defaultPadding),
                ),
    );
  }

  Widget loadingIndicator() {
    fetchPosts();
    return SizedBox(
      height: displayItems.isEmpty ? 0 : 64,
      child: displayItems.isEmpty
          ? null
          : Center(
              child: hasMore
                  ? const SizedBox.square(
                      dimension: 24,
                      child: CircularProgressIndicator(strokeWidth: 3),
                    )
                  : const Text("That's it"),
            ),
    );
  }

/*
Function which will update the pending status of purchase to approved
*/
  Future<void> approvePurchase(PostModel postModel) async {
    if (postModel.paymentResult?.purchaseId == null ||
        postModel.paymentResult?.productID == null) {
      Fluttertoast.showToast(
          msg: "Purchase ID or Product ID is null. Cannot approve.");
      return;
    }
    try {
      await firestore.collection("bought_new").doc(postModel.id).update({
        "status": 1,
      });
      Fluttertoast.showToast(msg: "Purchase approved successfully.");
      setState(() {
        displayItems.removeWhere((p) => p is PostModel && p.id == postModel.id);
      });
    } catch (e) {
      log("Failed to approve purchase: ${e.toString()}");
      Fluttertoast.showToast(msg: "Error approving purchase.");
    }
  }

/*
Function to reject the pending request for account purchase
Steps: 
1. Get document from bought_new
2. Create document in ff_ids with same id
3. Set paymentResult to null
4. Set data in FFIDS collection
5. Delete document from BoughtNew Collection
*/
  Future<void> rejectPurchase(PostModel postModel) async {
    WriteBatch batch = firestore.batch();
    try {
      DocumentReference boughtRef =
          firestore.collection("bought_new").doc(postModel.id);
      DocumentReference ffRef =
          firestore.collection("ff_ids").doc(postModel.id);
      postModel.paymentResult = null;
      postModel.status = 0;
      batch.set(ffRef, postModel.toMap());
      batch.delete(boughtRef);
      await batch.commit();
      Fluttertoast.showToast(
          msg: "Purchase rejected. Product is available again.");
      setState(() {
        displayItems.removeWhere((p) => p is PostModel && p.id == postModel.id);
      });
    } catch (e) {
      log("Failed to reject purchase: ${e.toString()}");
      Fluttertoast.showToast(msg: "Error rejecting purchase.");
    }
  }

/*
Function to revert the approved purchase
Steps: 
1. Get document from bought_new
2. Create document in ff_ids with same id
3. Set paymentResult to null
4. Set boughtBy to null
5. Set data in FFIDS collection
6. Delete document from BoughtNew Collection
*/
  Future<void> revertProduct(PostModel postModel) async {
    WriteBatch batch = firestore.batch();

    try {
      DocumentReference boughtRef =
          firestore.collection("bought_new").doc(postModel.id);
      DocumentReference ffRef =
          firestore.collection("ff_ids").doc(postModel.id);

      DocumentSnapshot boughtDoc = await boughtRef.get();

      if (!boughtDoc.exists) {
        Fluttertoast.showToast(msg: "Error: Product not found in bought_new.");
        return;
      }

      Map<String, dynamic> productData =
          boughtDoc.data() as Map<String, dynamic>;

      productData["paymentResult"] = null;
      productData["boughtBy"] = FieldValue.delete();
      productData["status"] = 0;

      // Apply batch operations
      batch.set(ffRef, productData, SetOptions(merge: true));
      batch.delete(boughtRef);

      await batch.commit();

      Fluttertoast.showToast(
          msg: "Purchase rejected. Product is available again.");
      Navigator.of(context).pop();

      setState(() {
        displayItems.removeWhere((p) => p is PostModel && p.id == postModel.id);
      });
    } catch (e, stackTrace) {
      log("Failed to revert product: ${e.toString()}");
      log(stackTrace.toString());
      Fluttertoast.showToast(msg: "Error reverting product.");
    }
  }
}

String decideTitleText(PostsType postsType) {
  switch (postsType) {
    case PostsType.latest:
      return "Latest Posts";
    case PostsType.popular:
      return "Popular Posts";
    case PostsType.elitepass:
      return "Elite Pass Accounts";
    case PostsType.diamonds:
      return "Diamonds Accounts";
    case PostsType.gunskins:
      return "Gun Skins Accounts";
    case PostsType.clothes:
      return "Rare Clothes Accounts";
    case PostsType.newId:
      return "New Accounts";
    case PostsType.myIds:
      return "My Accounts";
    default:
      return "Posts";
  }
}

// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:ffids_dark/widgets/home_posts_list.dart';
// import 'package:flutter/material.dart';
// import '../data/constants.dart';
// import '../data/posts_type.dart';
// import '../models/post_model.dart';
// import '../services/firestore_service.dart';
// import '../widgets/posts_listtile.dart';

// class PostsScreen extends StatefulWidget {
//   final CollectionReference<Map<String, dynamic>>? reference;
//   final bool isApprovePage;

//   const PostsScreen({
//     super.key,
//     required this.postsType,
//     this.reference,
//     this.isApprovePage = false,
//   });

//   final PostsType postsType;

//   @override
//   State<PostsScreen> createState() => _PostsScreenState();
// }

// class _PostsScreenState extends State<PostsScreen> {
//   int page = 1, limit = 10;
//   bool isLoading = false, hasMore = true;
//   DocumentSnapshot<Object?>? lastDoc;
//   List<dynamic> displayItems = []; // List to hold posts & ads
//   List<int> adPattern = [3, 5, 7, 5, 5, 5, 5]; // Ad insertion pattern

//   @override
//   void initState() {
//     super.initState();
//     fetchPosts();
//   }

//   /// Fetches posts and inserts ads at predefined positions
//   Future<void> fetchPosts() async {
//     if (!hasMore || isLoading) return;
//     isLoading = true;

//     try {
//       var (posts, doc) =
//           await FirestoreService.fetchPostsByType(widget.postsType, lastDoc);
//       if (posts != null) {
//         lastDoc = doc;
//         hasMore = posts.length >= limit;
//         insertAds(posts);
//       }
//     } catch (e) {
//       hasMore = false;
//     }

//     isLoading = false;
//     if (mounted) setState(() {});
//   }

//   /// Inserts ads based on the predefined pattern
//   void insertAds(List<PostModel> posts) {
//     List<dynamic> newDisplayItems = [];
//     int index = 0, patternIndex = 0;

//     while (index < posts.length) {
//       int interval =
//           (patternIndex < adPattern.length) ? adPattern[patternIndex] : 5;
//       int endIndex = (index + interval).clamp(0, posts.length);

//       newDisplayItems.addAll(posts.sublist(index, endIndex));
//       index = endIndex;
//       patternIndex++;

//       if (index < posts.length) {
//         newDisplayItems.add(const BannerAdWidget()); // Add Ad Widget
//       }
//     }

//     displayItems.addAll(newDisplayItems);
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         leading: IconButton(
//           onPressed: () => Navigator.pop(context),
//           icon: const Icon(Icons.keyboard_backspace_rounded),
//         ),
//         title: Text(
//           decideTitleText(widget.postsType),
//           style: Theme.of(context).textTheme.titleMedium,
//         ),
//       ),
//       body: isLoading && displayItems.isEmpty
//           ? const Center(child: CircularProgressIndicator(strokeWidth: 3))
//           : displayItems.isEmpty
//               ? const Center(child: Text("No Posts Found"))
//               : ListView.separated(
//                   key: const PageStorageKey('posts-list'),
//                   padding: const EdgeInsets.all(defaultPadding),
//                   itemCount: displayItems.length + 1,
//                   itemBuilder: (context, index) {
//                     if (index < displayItems.length) {
//                       var item = displayItems[index];

//                       if (item is PostModel) {
//                         return PostsListTile(postModel: item);
//                       } else {
//                         return item; // Ad Widget
//                       }
//                     } else {
//                       return loadingIndicator();
//                     }
//                   },
//                   separatorBuilder: (context, index) =>
//                       const SizedBox(height: defaultPadding),
//                 ),
//     );
//   }

//   /// Loading indicator at the end of the list
//   Widget loadingIndicator() {
//     fetchPosts();
//     return SizedBox(
//       height: displayItems.isEmpty ? 0 : 64,
//       child: displayItems.isEmpty
//           ? null
//           : Center(
//               child: hasMore
//                   ? const SizedBox.square(
//                       dimension: 24,
//                       child: CircularProgressIndicator(strokeWidth: 3),
//                     )
//                   : const Text("That's it"),
//             ),
//     );
//   }
// }

// /// Determines the screen title based on post type
// String decideTitleText(PostsType postsType) {
//   switch (postsType) {
//     case PostsType.latest:
//       return "Latest Posts";
//     case PostsType.popular:
//       return "Popular Posts";
//     case PostsType.elitepass:
//       return "Elite Pass Accounts";
//     case PostsType.diamonds:
//       return "Diamonds Accounts";
//     case PostsType.gunskins:
//       return "Gun Skins Accounts";
//     case PostsType.clothes:
//       return "Rare Clothes Accounts";
//     case PostsType.newId:
//       return "New Accounts";
//     case PostsType.myIds:
//       return "My Accounts";
//     default:
//       return "Posts";
//   }
// }
