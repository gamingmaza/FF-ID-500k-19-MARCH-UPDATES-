import 'dart:developer';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ffids_dark/data/firebase_banner_ad_info.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart' as rtdb;
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../data/constants.dart';
import '../data/posts_type.dart';
import '../models/chat_model.dart';
import '../models/post_model.dart';
import '../models/search_query_model.dart';
import '../utils/decide_post_query_by_post_type.dart';
import '../utils/show_alert.dart';

class FirestoreService {
  static final ads = FirebaseFirestore.instance.collection('ads');
  static final posts = FirebaseFirestore.instance.collection('ff_ids');
  static final bought = FirebaseFirestore.instance.collection('bought_new');
  static final chats = FirebaseFirestore.instance.collection('chats');
  static final users = FirebaseFirestore.instance.collection('users');
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final rtdb.DatabaseReference _database =
      rtdb.FirebaseDatabase.instance.ref(); // Use .ref()
  // static Future<void> createUserDatabase(User currentUser) async {
  //   try {
  //     users.doc(currentUser.uid).set({
  //       'name': currentUser.displayName,
  //       'email': currentUser.email,
  //       'photoUrl': currentUser.photoURL,
  //       'fcm_token': FirebaseMessaging.instance.getToken(),
  //     });
  //   } on FirebaseException catch (exception) {
  //     throw exception.message ?? exception.code;
  //   } catch (_) {
  //     rethrow;
  //   }
  // }
  static Future<void> createUserDatabase(User currentUser) async {
    try {
      String? token = await FirebaseMessaging.instance.getToken();
      await users.doc(currentUser.uid).set({
        'name': currentUser.displayName,
        'email': currentUser.email,
        'photoUrl': currentUser.photoURL,
        'fcm_token': token, // Ensures the token is fetched before writing
      });
    } on FirebaseException catch (exception) {
      throw exception.message ?? exception.code;
    } catch (_) {
      rethrow;
    }
  }

  static Future<List<PostModel>?> searchFromQuery(
      SearchQueryModel queryModel) async {
    try {
      Query query = posts;
      if (queryModel.queryText != null) {
        query = query.where('title', isEqualTo: queryModel.queryText);
      }
      if (queryModel.category != null) {
        query = query.where('category', isEqualTo: queryModel.category);
      }
      if (queryModel.priceRange != null) {
        query = query.where(
          'price',
          isGreaterThanOrEqualTo: queryModel.priceRange!.start,
          isLessThanOrEqualTo: queryModel.priceRange!.end,
        );
      }

      final fetchedPosts = await query.limit(10).get();
      return fetchedPosts.docs
          .map((post) => PostModel.fromSnapshot(post.id, post))
          .toList();
    } on FirebaseException catch (exception) {
      throw exception.message ?? exception.code;
    } catch (_) {
      rethrow;
    }
  }

  static Future<(List<PostModel>?, DocumentSnapshot<Object?>?)>
      fetchPostsByType(
    PostsType postsType,
    DocumentSnapshot<Object?>? documentSnapshot, [
    int? limit,
    CollectionReference<Map<String, dynamic>>? reference,
  ]) async {
    try {
      var query = decidePostQueryByPostType(postsType, reference ?? posts);

      if (documentSnapshot != null) {
        query = query.startAfterDocument(documentSnapshot);
      }

      // Fetch documents with or without a limit
      final fetchedPosts =
          limit != null ? await query.limit(limit).get() : await query.get();

      if (fetchedPosts.docs.isEmpty) {
        return (List<PostModel>.empty(), null);
      }

      // Convert Firestore documents to PostModel list
      final list = fetchedPosts.docs
          .map((post) => PostModel.fromSnapshot(post.id, post))
          .toList();

      list.sort((a, b) {
        final dateA = a.date;
        final dateB = b.date;

        if (dateA == null && dateB == null) return 0; // Both null, keep order
        if (dateA == null) return 1; // Null comes last
        if (dateB == null) return -1; // Null comes last for dateB

        return dateB.compareTo(dateA); // Sort descending (latest first)
      });
      log("Ref:${postsType.toString()} -> Length: ${list.length}");
      return (list, fetchedPosts.docs.last);
    } on FirebaseException catch (exception) {
      throw exception.message ?? exception.code;
    } catch (_) {
      rethrow;
    }
  }

  // static Future<(List<PostModel>?, DocumentSnapshot<Object?>)> fetchPostsByType(
  //     PostsType postsType, DocumentSnapshot<Object?>? documentSnapshot,
  //     [int? limit,
  //     CollectionReference<Map<String, dynamic>>? reference]) async {
  //   try {
  //     var query = decidePostQueryByPostType(postsType, reference ?? posts);
  //     if (documentSnapshot != null) {
  //       query = query.startAfterDocument(documentSnapshot);
  //     }
  //     final fetchedPosts = await query.limit(limit ?? 2000).get();
  //     final list = fetchedPosts.docs
  //         .map((post) => PostModel.fromSnapshot(post.id, post))
  //         .toList();

  //     return (list, fetchedPosts.docs.last);
  //   } on FirebaseException catch (exception) {
  //     throw exception.message ?? exception.code;
  //   } catch (_) {
  //     rethrow;
  //   }
  // }

  static Future<bool> uploadId(PostModel postModel) async {
    try {
      await posts.doc(postModel.id).set(postModel.toMap());

      return true;
    } on FirebaseException catch (exception) {
      throw exception.message ?? exception.code;
    } catch (_) {
      rethrow;
    }
  }

  static Future<bool> uploadIdNew(PostModel postModel) async {
    try {
      await bought.doc(postModel.id).set(postModel.toMap());
      return true;
    } on FirebaseException catch (exception) {
      throw exception.message ?? exception.code;
    } catch (_) {
      rethrow;
    }
  }

  static Future<void> deleteId(PostModel postModel,
      {bool keepImages = false}) async {
    try {
      await bought.doc(postModel.id).delete();
    } catch (e) {
      log(e.toString());
    }
    try {
      await posts.doc(postModel.id).delete();
    } catch (e) {
      log(e.toString());
    }
    try {
      if (!keepImages) {
        await FirebaseStorage.instance.refFromURL(postModel.imageUrl).delete();
      }
    } catch (e) {
      log(e.toString());
    }
    try {
      if (!keepImages) {
        await FirebaseStorage.instance.refFromURL(postModel.thumbnail).delete();
      }
    } catch (e) {
      log(e.toString());
    }
    showSuccessAlert(message: "Post deleted successfully!");
  }

  static Future<(List<ChatModel>, DocumentSnapshot<Object?>?)> getChats(
      String userId, bool getBuyers, int limit,
      [DocumentSnapshot<Object?>? lastDoc]) async {
    try {
      Query query = chats
          .where(getBuyers ? 'sellerId' : 'buyerId', isEqualTo: userId)
          .orderBy('date', descending: true)
          .limit(limit);

      if (lastDoc != null) {
        query = query.startAfterDocument(lastDoc);
      }

      final fetchedChats = await query.get();

      if (fetchedChats.docs.isEmpty) {
        return (List<ChatModel>.empty(), null);
      }

      final list = fetchedChats.docs
          .map((chat) => ChatModel.fromSnapshot(
              chat.id, chat as QueryDocumentSnapshot<Map<String, dynamic>>))
          .toList();

      return (list, fetchedChats.docs.last);
    } on FirebaseException catch (exception) {
      throw exception.message ?? exception.code;
    } catch (_) {
      rethrow;
    }
  }

  // static Future<(List<ChatModel>?, DocumentSnapshot<Object?>)> getChats(
  //     String userId, bool getBuyers, int limit) async {
  //   try {
  //     final fetchedChats = await chats
  //         .where(getBuyers ? 'sellerId' : 'buyerId', isEqualTo: userId)
  //         .orderBy('date', descending: true)
  //         .limit(limit)
  //         .get();
  //     final list = fetchedChats.docs
  //         .map((chat) => ChatModel.fromSnapshot(chat.id, chat))
  //         .toList();
  //     return (list, fetchedChats.docs.last);
  //   } on FirebaseException catch (exception) {
  //     throw exception.message ?? exception.code;
  //   } catch (_) {
  //     rethrow;
  //   }
  // }

  static Future<String?> sellerChatDocId(User user, PostModel postModel) async {
    Future<String?> attemptChatCreation({bool isRetry = false}) async {
      try {
        final s1 = user.uid, s2 = postModel.authorId;
        String docId = (s1.compareTo(s2) < 0) ? '$s1$s2' : '$s1$s2';
        final fetchedChat = await chats.doc(docId).get();

        if (!fetchedChat.exists) {
          final newChat = ChatModel(
            docId: docId,
            buyerId: user.uid,
            buyerName: user.displayName ?? '',
            buyerPhotoUrl: user.photoURL ?? '',
            sellerId: postModel.authorId,
            sellerName: postModel.authorName,
            sellerPhotoUrl: postModel.authorPhoto,
            messages: [],
            lastMessage: '',
            date: Timestamp.now(),
          );
          await chats.doc(docId).set(newChat.toMap());
          await posts
              .doc(postModel.id)
              .update({'sellerContactCount': FieldValue.increment(1)});
        }
        return docId;
      } on FirebaseException catch (e) {
        if (!isRetry &&
            (e.code == 'permission-denied' ||
                e.message ==
                    "The caller does not have permission to execute the specified operation.")) {
          return attemptChatCreation(isRetry: true);
        }
        log(e.code);
        log(e.message ?? "");
        showErrorAlert(message: e.message ?? e.code);
      } catch (e) {
        log('outside fbexception: ${e.toString()}');
        showErrorAlert(
          message: e.runtimeType == String ? '$e' : '${e.runtimeType}',
        );
      }
      return null;
    }

    return attemptChatCreation();
  }

  // static Future<String?> sellerChatDocId(User user, PostModel postModel) async {
  //   try {
  //     final s1 = user.uid, s2 = postModel.authorId;
  //     String docId = (s1.compareTo(s2) < 0) ? '$s1$s2' : '$s1$s2';
  //     final fetchedChat = await chats.doc(docId).get();
  //     if (!fetchedChat.exists) {
  //       final newChat = ChatModel(
  //         docId: docId,
  //         buyerId: user.uid,
  //         buyerName: user.displayName ?? '',
  //         buyerPhotoUrl: user.photoURL ?? '',
  //         sellerId: postModel.authorId,
  //         sellerName: postModel.authorName,
  //         sellerPhotoUrl: postModel.authorPhoto,
  //         messages: [],
  //         lastMessage: '',
  //         date: Timestamp.now(),
  //       );
  //       chats.doc(docId).set(newChat.toMap());
  //       await posts
  //           .doc(postModel.id)
  //           .update({'sellerContactCount': FieldValue.increment(1)});
  //       return docId;
  //     } else {
  //       return docId;
  //     }
  //   } on FirebaseException catch (e) {
  //     log(e.code);
  //     log(e.message ?? "");
  //     showErrorAlert(message: e.message ?? e.code);
  //   } catch (e) {
  //     log('outside fbexception: ${e.toString()}');
  //     showErrorAlert(
  //       message: e.runtimeType == String ? '$e' : '${e.runtimeType}',
  //     );
  //   }
  //   return null;
  // }

  static Future<PostModel?> fetchPostDetailsById(String docId) async {
    try {
      final fetchedPost = await posts.doc(docId).get();
      return PostModel(
        id: fetchedPost.id,
        title: fetchedPost['title'] ?? 'Unknown',
        thumbnail: fetchedPost['thumbnail'] ?? '',
        description: fetchedPost['description'] ?? '',
        category: fetchedPost['category'] ?? '',
        authorId: fetchedPost['authorId'],
        imageUrl: fetchedPost['imageUrl'],
        date: fetchedPost['date'],
        price: fetchedPost['price'],
        sellerContactCount: fetchedPost['sellerContactCount'] ?? 0,
        authorName: fetchedPost['authorName'],
        authorPhoto: fetchedPost['authorPhoto'] ?? defaultProfilePhotoUrl,
        otherImages: List<String>.from(
            fetchedPost['otherImages'] ?? []), // Added other images
      );
    } catch (e) {
      rethrow;
    }
  }

  /// Uploads a new Banner Ad, ensuring only one document exists
  Future<bool> uploadBannerAd({
    required File imageFile,
    required String adUrl,
    required double height,
  }) async {
    try {
      // Reference to Firestore collection
      CollectionReference bannerAdCollection =
          _firestore.collection("BannerAdData");

      // Fetch existing document (should only be one)
      QuerySnapshot querySnapshot = await bannerAdCollection.get();

      if (querySnapshot.docs.isNotEmpty) {
        // If a document exists, delete the old image and document
        DocumentSnapshot oldDoc = querySnapshot.docs.first;
        String? oldImageUrl = oldDoc["imageUrl"];

        if (oldImageUrl != null && oldImageUrl.isNotEmpty) {
          await _deleteImageFromStorage(oldImageUrl);
        }

        await oldDoc.reference.delete(); // Delete old document
      }

      // Upload new image to Firebase Storage
      String newImageUrl = await _uploadImageToStorage(imageFile);

      // Save new ad data in Firestore
      await bannerAdCollection.doc("banner_ad").set({
        "imageUrl": newImageUrl,
        "adUrl": adUrl,
        "height": height,
      });

      Fluttertoast.showToast(msg: "✅ Banner Ad uploaded successfully!");
      return true;
    } catch (e) {
      Fluttertoast.showToast(
        msg: "❌ Error uploading Banner Ad: $e",
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
      return false;
    }
  }

  /// Fetches the Banner Ad document and returns a BannerAd object
  Future<FireBaseBannerAdInfo?> fetchBannerAd() async {
    try {
      CollectionReference bannerAdCollection =
          _firestore.collection("BannerAdData");

      QuerySnapshot querySnapshot = await bannerAdCollection.get();

      if (querySnapshot.docs.isNotEmpty) {
        DocumentSnapshot doc = querySnapshot.docs.first;
        return FireBaseBannerAdInfo.fromMap(doc.data() as Map<String, dynamic>);
      } else {
        log("⚠️ No banner ad found.");
        return null;
      }
    } catch (e) {
      log("❌ Error fetching Banner Ad: $e");
      return null;
    }
  }

  /// Uploads an image to Firebase Storage
  Future<String> _uploadImageToStorage(File imageFile) async {
    try {
      Reference storageRef = _storage
          .ref()
          .child("BannerAdImages/${DateTime.now().millisecondsSinceEpoch}.jpg");

      UploadTask uploadTask = storageRef.putFile(imageFile);
      TaskSnapshot snapshot = await uploadTask;

      return await snapshot.ref.getDownloadURL();
    } catch (e) {
      throw Exception("❌ Failed to upload image: $e");
    }
  }

  /// Deletes an image from Firebase Storage
  Future<void> _deleteImageFromStorage(String imageUrl) async {
    try {
      Reference storageRef = _storage.refFromURL(imageUrl);
      await storageRef.delete();
      log("✅ Old image deleted successfully.");
    } catch (e) {
      log("❌ Error deleting old image: $e");
    }
  }

// Fetch 'showAd' value from Firebase
  Future<bool?> getShowAdValue() async {
    try {
      rtdb.DatabaseEvent event =
          await _database.child("showAd").once(); // Updated method
      return event.snapshot.value as bool?;
    } catch (e) {
      print("Error fetching showAd value: $e");
      return null;
    }
  } // Toggle 'showAd' value in Firebase

  Future<bool> toggleShowAd() async {
    try {
      bool? currentValue = await getShowAdValue();
      if (currentValue != null) {
        await _database.child("showAd").set(!currentValue);
        return true; // Successfully toggled
      }
    } catch (e) {
      print("Error toggling showAd value: $e");
    }
    return false; // Return false if an error occurs
  }
}
