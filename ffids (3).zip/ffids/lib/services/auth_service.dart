import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

import '../utils/show_alert.dart';

class AuthService {
  static final _firebaseAuth = FirebaseAuth.instance;
  User? get user => _firebaseAuth.currentUser;
  static Stream<User?> userState() => _firebaseAuth.authStateChanges();

  static Future<User?> login(String email, String password) async {
    if (email.isEmpty) {
      showErrorAlert(message: "Enter Valid Email");
      return null;
    } else if (password.isEmpty) {
      showErrorAlert(message: "Enter valid Password");
      return null;
    } else {
      try {
        final userCredential = await _firebaseAuth.signInWithEmailAndPassword(
          email: email,
          password: password,
        );
        return userCredential.user;
      } on FirebaseAuthException catch (exception) {
        showErrorAlert(message: exception.message ?? "Something went wrong :(");
        return null;
      }
    }
  }

  static Future<bool> forgotPassword(String email) async {
    if (email.isEmpty) {
      showErrorAlert(message: "Enter a valid email");
      return false;
    } else {
      try {
        await _firebaseAuth.sendPasswordResetEmail(email: email);
        return true;
      } on FirebaseAuthException catch (exception) {
        showErrorAlert(message: exception.message ?? 'Something went wrong :(');
        return false;
      }
    }
  }

  static Future<User?> signUp(name, email, password) async {
    if (name.isEmpty) {
      showErrorAlert(message: "Enter a valid Name");
      return null;
    } else if (email.isEmpty) {
      showErrorAlert(message: "Enter valid Email");
      return null;
    } else if (password.isEmpty) {
      showErrorAlert(message: "Enter valid Password");
      return null;
    } else {
      try {
        final credential = await _firebaseAuth.createUserWithEmailAndPassword(
          email: email,
          password: password,
        );
        if (credential.user != null) credential.user!.updateDisplayName(name);
        return credential.user;
      } on FirebaseAuthException catch (exception) {
        showErrorAlert(message: exception.message ?? "Something went wrong :(");
        return null;
      }
    }
  }

  static Future<void> logout() async {
    return await _firebaseAuth.signOut();
  }

  static Future<User?> loginWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
      if (googleUser == null) {
        // User canceled sign-in
        showErrorAlert(message: "Sign-in cancelled");
        return null;
      }
      final googleAuth = await googleUser.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );
      final _ = await _firebaseAuth.signInWithCredential(credential);
      return _.user;
    } on FirebaseAuthException catch (exception) {
      showErrorAlert(message: exception.message ?? "Something went wrong :(");
      return null;
    } catch (e) {
      showErrorAlert(message: e.toString());
      return null;
    }
  }
}
