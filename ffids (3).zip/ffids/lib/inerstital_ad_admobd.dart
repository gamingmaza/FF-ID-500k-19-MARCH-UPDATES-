import 'dart:developer';
import 'package:ffids_dark/core/admob_ad_ids.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

class InterstitialAdController {
  InterstitialAd? _interstitialAd;
  bool isAdLoaded = false;
  bool isLoading = false; // Prevents multiple load calls

  void load() {
    if (isLoading || isAdLoaded) return; // Prevent unnecessary loading

    isLoading = true;
    InterstitialAd.load(
      // adUnitId: 'ca-app-pub-3940256099942544/1033173712', // Test Ad ID
      adUnitId: AdxIds.adxInterstitalAdID,
      // request: AdRequest(),  // ❌ This is for AdMob, NOT AdX
      request: AdManagerAdRequest(), // ✅ Use AdManagerAdRequest() for AdX
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (InterstitialAd ad) {
          _interstitialAd = ad;
          isAdLoaded = true;
          isLoading = false;
          // log("✅ Interstitial Ad Loaded");
        },
        onAdFailedToLoad: (LoadAdError error) {
          log("❌ Failed to Load Interstitial Ad: ${error.message}");
          _interstitialAd = null;
          isAdLoaded = false;
          isLoading = false;
        },
      ),
    );
  }

  void show() {
    if (_interstitialAd != null) {
      _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
        onAdDismissedFullScreenContent: (InterstitialAd ad) {
          log("✅ Ad Dismissed");
          _disposeAd();
          load(); // Reload after dismissal
        },
        onAdFailedToShowFullScreenContent: (InterstitialAd ad, AdError error) {
          log("❌ Failed to Show Interstitial Ad: ${error.message}");
          _disposeAd();
          load();
        },
      );

      log("🎬 Showing Interstitial Ad...");
      _interstitialAd!.show();
    } else {
      log("❌ No Interstitial Ad Available to Show");
      load(); // Attempt to load a new ad
    }
  }

  void _disposeAd() {
    _interstitialAd?.dispose();
    _interstitialAd = null;
    isAdLoaded = false;
  }
}
