import 'dart:convert';
import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ffids_dark/models/payment_model.dart';
import 'package:ffids_dark/models/post_model.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:waveui/waveui.dart';

class PurchaseController extends GetxController {
  var isBusy = false.obs;
  var firestore = FirebaseFirestore.instance;
  var auth = FirebaseAuth.instance;
  late PostModel postModel;
  var inAppPurchase = InAppPurchase.instance;
  var products = <ProductDetails>[];
  var isAvailable = true.obs;

  initConfig() async {
    isBusy.value = true;
    if (!(await inAppPurchase.isAvailable())) {
      Fluttertoast.showToast(msg: "In app purchase not available");
      Get.back();
    }
    await fetchConsumableProducts();
    isBusy.value = false;
  }

  Future<void> fetchConsumableProducts() async {
    final Set<String> productIds = {'product${postModel.price.round()}'};
    final ProductDetailsResponse response =
        await inAppPurchase.queryProductDetails(productIds);

    if (response.notFoundIDs.isNotEmpty) {
      print('Some product IDs were not found: ${response.notFoundIDs}');
      isAvailable.value = false;
    }

    products = response.productDetails;

    inAppPurchase.purchaseStream.listen((event) async {
      if (event.first.status == PurchaseStatus.pending) {
        Fluttertoast.showToast(
            msg: "Processing payment. Don't close.",
            toastLength: Toast.LENGTH_LONG);
      } else {
        if (event.first.status == PurchaseStatus.error) {
          Fluttertoast.showToast(
              msg: event.first.error?.message ?? "Failed to purchase");
          // } else if (event.first.status == PurchaseStatus.purchased ||
          //     event.first.status == PurchaseStatus.restored) {
        } else if (event.first.status == PurchaseStatus.purchased) {
          Fluttertoast.showToast(msg: "Admin will verify your payment");
          await buyProduct({
            "purchaseId": event.first.purchaseID,
            "productID": event.first.productID,
            "transactionDate": event.first.transactionDate,
            "errorMessage": event.first.error?.message,
            "errorCode": event.first.error?.code,
            "errorSource": event.first.error?.source,
            "user": auth.currentUser?.email,
            "uid": auth.currentUser?.uid,
            "name": auth.currentUser?.displayName,
          });
          await inAppPurchase.completePurchase(event.first);
        }
      }

      log(jsonEncode({
        "purchaseId": event.first.purchaseID,
        "productID": event.first.productID,
        "transactionDate": event.first.transactionDate,
        "errorMessage": event.first.error?.message,
        "errorCode": event.first.error?.code,
        "errorSource": event.first.error?.source,
        "user": auth.currentUser?.email,
        "uid": auth.currentUser?.uid,
        "name": auth.currentUser?.displayName,
      }));
    });
  }

  Future<void> buy() async {
    var item = products.first;
    await inAppPurchase.buyConsumable(
      purchaseParam: PurchaseParam(
        productDetails: item,
        applicationUserName: auth.currentUser?.uid,
      ),
      autoConsume: true,
    );
  }

  Future<void> buyProduct(Map<String, dynamic> data) async {
    if (auth.currentUser == null) {
      Fluttertoast.showToast(msg: "Not valid user. Please login.");
      return;
    }
    isBusy.value = true;
    postModel.status = 0;
    postModel.paymentResult = PaymentResultModel.fromMap(data);
    postModel.boughtBy = auth.currentUser?.uid;
    var doc = await firestore.collection("ff_ids").doc(postModel.id).get();

    if (!doc.exists) {
      Fluttertoast.showToast(msg: "Not found");
      Get.back();
      return;
    }
    try {
      await firestore.collection("ff_ids").doc(postModel.id).delete();
    } catch (e) {
      log("Failed to delete ${postModel.id}");
    }
    await firestore
        .collection("bought_new")
        .doc(postModel.id)
        .set(postModel.toMap());
    Fluttertoast.showToast(msg: "Successful");
    Get.back();
    Get.back();
    isBusy.value = false;
  }
}
