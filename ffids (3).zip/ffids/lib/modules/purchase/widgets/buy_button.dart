import 'package:ffids_dark/data/constants.dart';
import 'package:ffids_dark/models/post_model.dart';
import 'package:ffids_dark/modules/purchase/controllers/purchase_controller.dart';
import 'package:waveui/waveui.dart';

class BuyButton extends StatefulWidget {
  final PostModel postModel;
  const BuyButton({super.key, required this.postModel});

  @override
  State<BuyButton> createState() => _BuyButtonState();
}

class _BuyButtonState extends State<BuyButton> {
  final controller = PurchaseController();

  @override
  void initState() {
    super.initState();
    controller.postModel = widget.postModel;
    controller.initConfig();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.6,
      height: 64,
      child: Material(
        color: primaryColor,
        borderRadius: BorderRadius.circular(64),
        clipBehavior: Clip.hardEdge,
        child: Obx(
          () => InkWell(
            onTap: controller.isAvailable.value ? () => controller.buy() : null,
            child: Center(
              child: Obx(
                () => controller.isBusy.value
                    ? const SizedBox.square(
                        dimension: 32,
                        child: CircularProgressIndicator(
                          color: Colors.white,
                          strokeWidth: 3,
                        ),
                      )
                    : Text(
                        controller.isAvailable.value
                            ? "Buy Now ${controller.postModel.price.round()}\$"
                            : "Not Available",
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                        ),
                      ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
