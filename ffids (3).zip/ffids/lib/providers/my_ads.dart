// import 'package:flutter/material.dart';

// import '../models/my_ad_model.dart';
// import '../models/my_video_ad_model.dart';
// import '../services/firestore_service.dart';

// class MyAdProvider extends ChangeNotifier {
//   final _query = FirestoreService.ads.where('active', isEqualTo: true);
//   MyAdModel? banner;
//   MyAdModel? mediumBanner;
//   MyAdModel? largeBanner;
//   MyVideoAdModel? video;

//   Future<void> initialize() async {
//     var bannerSnapshot =
//         await _query.where('type', isEqualTo: 'banner').limit(1).get();
//     if (bannerSnapshot.docs.isNotEmpty) {
//       final data = bannerSnapshot.docs.first.data();
//       banner = MyAdModel.fromMap(data);
//     } else {
//       banner = null;
//     }

//     var mediumBannerSnapshot =
//         await _query.where('type', isEqualTo: 'mediumBanner').limit(1).get();
//     if (mediumBannerSnapshot.docs.isNotEmpty) {
//       final data = mediumBannerSnapshot.docs.first.data();
//       mediumBanner = MyAdModel.fromMap(data);
//     } else {
//       mediumBanner = null;
//     }

//     var largeBannerSnapshot =
//         await _query.where('type', isEqualTo: 'largeBanner').limit(1).get();
//     if (largeBannerSnapshot.docs.isNotEmpty) {
//       final data = largeBannerSnapshot.docs.first.data();
//       largeBanner = MyAdModel.fromMap(data);
//     } else {
//       largeBanner = null;
//     }

//     var videoAdSnapshot =
//         await _query.where('type', isEqualTo: 'video').limit(1).get();
//     if (videoAdSnapshot.docs.isNotEmpty) {
//       final data = videoAdSnapshot.docs.first.data();
//       video = MyVideoAdModel.fromMap(data);
//     } else {
//       video = null;
//     }
//     notifyListeners();
//   }
// }
