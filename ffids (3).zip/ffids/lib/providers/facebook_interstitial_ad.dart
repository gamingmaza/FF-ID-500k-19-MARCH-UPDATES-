// import 'package:facebook_audience_network/ad/ad_interstitial.dart';

// import '../data/facebook_ad_id.dart';

// class FacebookInterstitialAdProvider {
//   bool _isLoaded = false;

//   load() async {
//     if (!_isLoaded) {
//       await FacebookInterstitialAd.loadInterstitialAd(
//         placementId: MyFacebookAdIds.interstitialAdId,
//         listener: (result, value) async {
//           _isLoaded = (result == InterstitialAdResult.LOADED);
//           if (result == InterstitialAdResult.LOGGING_IMPRESSION) {
//             await FacebookInterstitialAd.destroyInterstitialAd();
//             _isLoaded = false;
//             load();
//           }
//         },
//       );
//     }
//   }

//   show() async {
//     if (_isLoaded) {
//       await FacebookInterstitialAd.showInterstitialAd(delay: 0);
//     } else {
//       load();
//     }
//   }
// }
