import 'package:firebase_auth/firebase_auth.dart';

class UserStateProvider {
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;

  Stream<User?> get currentUser => _firebaseAuth.authStateChanges();
}
