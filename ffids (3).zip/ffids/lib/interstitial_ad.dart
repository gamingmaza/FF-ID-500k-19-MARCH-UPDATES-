// import 'dart:math';

// import 'package:applovin_max/applovin_max.dart';
// import 'package:ffids_dark/main.dart';
// import 'package:flutter/material.dart';

// import 'core/appvolin_ad_ids.dart';

// class AdxInterstitialAdController {
//   static const int _maxExponentialRetryCount = 6;
//   var _interstitialRetryAttempt = 0;

//   void initializeInterstitialAds() {
//     try {
//       if (isAppvolingInitialized) {
//         AppLovinMAX.setInterstitialListener(InterstitialListener(
//           onAdLoadedCallback: (ad) {
//             // Interstitial ad is ready to show. AppLovinMAX.isInterstitialReady(_interstitial_ad_unit_id) now returns 'true'
//             debugPrint('Interstitial ad loaded from ${ad.networkName}');

//             // Reset retry attempt
//             _interstitialRetryAttempt = 0;
//           },
//           onAdLoadFailedCallback: (adUnitId, error) {
//             // Interstitial ad failed to load
//             // AppLovin recommends that you retry with exponentially higher delays up to a maximum delay (in this case 64 seconds)
//             _interstitialRetryAttempt = _interstitialRetryAttempt + 1;

//             if (_interstitialRetryAttempt > _maxExponentialRetryCount) return;

//             int retryDelay = pow(2,
//                     min(_maxExponentialRetryCount, _interstitialRetryAttempt))
//                 .toInt();

//             debugPrint(
//                 'Interstitial ad failed to load with code ${error.code} - retrying in ${retryDelay}s');

//             Future.delayed(Duration(milliseconds: retryDelay * 1000), () {
//               AppLovinMAX.loadInterstitial(intertitialAdId);
//             });
//           },
//           onAdDisplayedCallback: (ad) {},
//           onAdDisplayFailedCallback: (ad, error) {},
//           onAdClickedCallback: (ad) {},
//           onAdHiddenCallback: (ad) {
//             AppLovinMAX.loadInterstitial(intertitialAdId);
//           },
//         ));

//         // Load the first interstitial
//         AppLovinMAX.loadInterstitial(intertitialAdId);
//       } else {
//         initializePlugin();
//       }
//     } catch (e) {
//       debugPrint("Error In InertitalAd:${e.toString()}");
//     }
//   }

//   void showInteratialAd() async {
//     try {
//       if (isAppvolingInitialized) {
//         bool isReady =
//             (await AppLovinMAX.isInterstitialReady(intertitialAdId))!;
//         if (isReady) {
//           AppLovinMAX.showInterstitial(intertitialAdId);
//         } else {
//           initializeInterstitialAds();
//         }
//       } else {
//         initializePlugin();
//       }
//     } catch (e) {
//       debugPrint("Error showing ad:${e.toString()}");
//     }
//   }
// }

// enum AdLoadState { notLoaded, loading, loaded }
