import 'dart:async';
import 'package:ffids_dark/admob_openapp_ad_manager.dart';
import 'package:ffids_dark/firebase_options.dart';
import 'package:ffids_dark/inerstital_ad_admobd.dart';
import 'package:ffids_dark/utils/mycustom_scroll_behaviour.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/services.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:provider/provider.dart';
import 'package:waveui/waveui.dart';
import 'data/constants.dart';
import 'hive_models/favourite_posts.dart';
import 'providers/auth.dart';
import 'screens/auth/forget_password_screen.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/signup_screen.dart';
import 'screens/home_screen.dart';

late FirebaseAnalytics analytics;
final interstitialAdController = InterstitialAdController();
final AppOpenAdManager appOpenAdManager = AppOpenAdManager();
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarIconBrightness: Brightness.dark,
    statusBarBrightness: Brightness.light,
    statusBarColor: Colors.transparent,
    systemNavigationBarDividerColor: backgroundColor,
    systemNavigationBarColor: backgroundColor,
  ));
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // await FacebookAudienceNetwork.init();
  await Hive.initFlutter();
  unawaited(MobileAds.instance.initialize());
  RequestConfiguration requestConfiguration =
      RequestConfiguration(testDeviceIds: ["E9E2C4DE7AC7DC1F956A85FA145FFD88"]);
  MobileAds.instance.updateRequestConfiguration(requestConfiguration);
  Hive.registerAdapter(FavouritePostsAdapter());
  await Hive.openBox<FavouritePosts>('favourite_posts');
  await FirebaseMessaging.instance.requestPermission();
  analytics = FirebaseAnalytics.instance;
  await analytics.setAnalyticsCollectionEnabled(true);

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    interstitialAdController.load();
    return MultiProvider(
      providers: [
        Provider(create: (_) => UserStateProvider()),
        // Provider(create: (_) => FacebookInterstitialAdProvider()),
        // ChangeNotifierProvider(create: (_) => MyAdProvider()),
      ],
      child: GetMaterialApp(
        title: 'Buy & Sell',
        debugShowCheckedModeBanner: false,
        scrollBehavior: MyCustomScrollBehavior(),
        navigatorObservers: [
          FirebaseAnalyticsObserver(analytics: analytics),
        ],
        theme: ThemeData(
          useMaterial3: false,
          scaffoldBackgroundColor: backgroundColor,
          primarySwatch: Colors.orange,
          fontFamily: "Gordita",
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.transparent,
            centerTitle: true,
            elevation: 0,
            systemOverlayStyle: SystemUiOverlayStyle(
              statusBarIconBrightness: Brightness.dark,
              statusBarBrightness: Brightness.light,
              statusBarColor: Colors.transparent,
              systemNavigationBarDividerColor: Colors.transparent,
              systemNavigationBarColor: Colors.white,
              systemNavigationBarIconBrightness: Brightness.dark,
            ),
          ),
          textTheme: const TextTheme(
            headlineLarge: TextStyle(
              fontSize: 34,
              fontWeight: FontWeight.w500,
              color: Colors.black,
            ),
            headlineMedium: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.w500,
              color: Colors.black,
            ),
            headlineSmall: TextStyle(fontSize: 18),
            titleMedium: TextStyle(
              fontWeight: FontWeight.w500,
            ),
            bodyLarge: TextStyle(fontSize: 20),
          ),
          textButtonTheme: const TextButtonThemeData(
            style: ButtonStyle(
              foregroundColor: MaterialStatePropertyAll<Color>(Colors.black54),
            ),
          ),
          floatingActionButtonTheme: const FloatingActionButtonThemeData(
            backgroundColor: primaryColor,
            foregroundColor: Colors.white,
            extendedTextStyle: TextStyle(fontWeight: FontWeight.bold),
            elevation: 4,
          ),
          sliderTheme: const SliderThemeData(
            valueIndicatorColor: primaryColor,
            valueIndicatorTextStyle: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w500,
              color: Colors.white,
            ),
          ),
        ),
        initialRoute: '/',
        routes: {
          '/': (context) {
            final authProvider = Provider.of<UserStateProvider>(context);
            return StreamBuilder(
              stream: authProvider.currentUser,
              builder: (_, userSnapshot) => userSnapshot.data != null
                  ? const HomeScreen()
                  : const LoginScreen(),
            );
          },
          '/login': (_) => const LoginScreen(),
          '/signup': (_) => const SignUpScreen(),
          '/forget-password': (_) => const ForgetPasswordScreen(),
          '/home': (_) => const HomeScreen(),
        },
      ),
    );
  }
}

// Future<void> initializePlugin() async {
//   try {
//     debugPrint("Initializing SDK...");
//     // // MAX Consent Flow - https://dash.applovin.com/documentation/mediation/react-native/getting-started/terms-and-privacy-policy-flow
//     // AppLovinMAX.setTermsAndPrivacyPolicyFlowEnabled(true);
//     // AppLovinMAX.setPrivacyPolicyUrl("https://your_company_name.com/privacy");
//     // AppLovinMAX.setTermsOfServiceUrl("https://your_company_name.com/terms");

//     AppLovinMAX.initialize(sdkKey).then((value) {
//       if (value != null) {
//         debugPrint("SDK Initialized: ${value.countryCode}");
//         isAppvolingInitialized = true;
//       } else {
//         isAppvolingInitialized = false;
//       }
//     });
//   } catch (e) {
//     debugPrint("Error while initializing Applovin:$e");
//   }
// }

bool isAppvolingInitialized = false;
