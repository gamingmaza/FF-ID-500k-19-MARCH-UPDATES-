// import 'dart:math';

// import 'package:applovin_max/applovin_max.dart';

// import 'package:ffids_dark/core/appvolin_ad_ids.dart';
// import 'package:ffids_dark/main.dart';
// import 'package:flutter/material.dart';

// class RewardedAd {
//   var _rewardedAdLoadState = AdLoadState.notLoaded;
//   var _rewardedAdRetryAttempt = 0;
//   final _maxExponentialRetryCount = 6;
//   void initializeListener() {
//     try {
//       /// Rewarded Ad Listeners
//       AppLovinMAX.setRewardedAdListener(
//           RewardedAdListener(onAdLoadedCallback: (ad) {
//         _rewardedAdLoadState = AdLoadState.loaded;
//         // Rewarded ad is ready to be shown. AppLovinMAX.isRewardedAdReady(_rewarded_ad_unit_id) will now return 'true'
//         debugPrint('Rewarded ad loaded from ${ad.networkName}');

//         // Reset retry attempt
//         _rewardedAdRetryAttempt = 0;
//       }, onAdLoadFailedCallback: (adUnitId, error) {
//         _rewardedAdLoadState = AdLoadState.notLoaded;
//         // Rewarded ad failed to load
//         // We recommend retrying with exponentially higher delays up to a maximum delay (in this case 64 seconds)
//         _rewardedAdRetryAttempt = _rewardedAdRetryAttempt + 1;
//         if (_rewardedAdRetryAttempt > _maxExponentialRetryCount) {
//           debugPrint('Rewarded ad failed to load with code ${error.code}');
//           return;
//         }
//         int retryDelay =
//             pow(2, min(_maxExponentialRetryCount, _rewardedAdRetryAttempt))
//                 .toInt();
//         debugPrint(
//             'Rewarded ad failed to load with code ${error.code} - retrying in ${retryDelay}s');
//         Future.delayed(Duration(milliseconds: retryDelay * 1000), () {
//           _rewardedAdLoadState = AdLoadState.loading;
//           debugPrint('Rewarded ad retrying to load...');
//           Future.delayed(
//             const Duration(seconds: 31),
//             () {
//               // AppLovinMAX.loadRewardedAd(rewardAdId);
//             },
//           );
//         });
//       }, onAdDisplayedCallback: (ad) {
//         debugPrint('Rewarded ad displayed');
//       }, onAdDisplayFailedCallback: (ad, error) {
//         _rewardedAdLoadState = AdLoadState.notLoaded;
//         debugPrint(
//             'Rewarded ad failed to display with code ${error.code} and message ${error.message}');
//       }, onAdClickedCallback: (ad) {
//         debugPrint('Rewarded ad clicked');
//       }, onAdHiddenCallback: (ad) {
//         _rewardedAdLoadState = AdLoadState.notLoaded;
//         debugPrint('Rewarded ad hidden');
//         _rewardedAdLoadState = AdLoadState.loading;
//         AppLovinMAX.loadRewardedAd(rewardAdId);
//       }, onAdReceivedRewardCallback: (ad, reward) {
//         debugPrint('Rewarded ad granted reward');
//       }, onAdRevenuePaidCallback: (ad) {
//         debugPrint('Rewarded ad revenue paid: ${ad.revenue}');
//       }));
//       AppLovinMAX.showRewardedAd(rewardAdId);
//     } catch (e) {
//       debugPrint("Exception while showing rewarded ad:$e");
//     }
//   }

//   Future<void> showRewardedAd() async {
//     try {
//       if (isAppvolingInitialized &&
//           _rewardedAdLoadState != AdLoadState.loading) {
//         bool isReady = (await AppLovinMAX.isRewardedAdReady(rewardAdId))!;
//         if (isReady) {
//           AppLovinMAX.showRewardedAd(rewardAdId);
//         } else {
//           debugPrint('Loading rewarded ad...');
//           _rewardedAdLoadState = AdLoadState.loading;
//           AppLovinMAX.loadRewardedAd(rewardAdId);
//           // if (isAppvolingInitialized &&
//           //     _rewardedAdLoadState != AdLoadState.loading) {
//           //   debugPrint("Running beast running");
//           //   bool isReady = (await AppLovinMAX.isRewardedAdReady(rewardAdId))!;
//           //   if (isReady) {
//           //     AppLovinMAX.showRewardedAd(rewardAdId);
//           //   }
//           // } else {
//           //   debugPrint("Running beast not running");
//           // }
//         }
//       }
//     } catch (e) {
//       debugPrint("Exception while showing rewarded ad:$e");
//     }
//   }
// }

// enum AdLoadState { notLoaded, loading, loaded }
