class PaymentResultModel {
  final String? errorCode;
  final String? errorMessage;
  final String? errorSource;
  final String? name;
  final String? productID;
  final String? purchaseId;
  final String? transactionDate;
  final String? uid;
  final String? user;

  PaymentResultModel({
    this.errorCode,
    this.errorMessage,
    this.errorSource,
    this.name,
    this.productID,
    this.purchaseId,
    this.transactionDate,
    this.uid,
    this.user,
  });

  factory PaymentResultModel.fromMap(Map<String, dynamic>? data) {
    if (data == null) return PaymentResultModel();
    return PaymentResultModel(
      errorCode: data['errorCode'],
      errorMessage: data['errorMessage'],
      errorSource: data['errorSource'],
      name: data['name'],
      productID: data['productID'],
      purchaseId: data['purchaseId'],
      transactionDate: data['transactionDate'],
      uid: data['uid'],
      user: data['user'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'errorCode': errorCode,
      'errorMessage': errorMessage,
      'errorSource': errorSource,
      'name': name,
      'productID': productID,
      'purchaseId': purchaseId,
      'transactionDate': transactionDate,
      'uid': uid,
      'user': user,
    };
  }
}
