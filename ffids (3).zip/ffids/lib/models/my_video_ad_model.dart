// class MyVideoAdModel {
//   final String videoUrl, onVideoFinishImage, promotionalLink, title, buttonText;
//   final String type;
//   final int skipAfterSecond;
//   final bool active;

//   MyVideoAdModel({
//     required this.videoUrl,
//     required this.onVideoFinishImage,
//     required this.promotionalLink,
//     required this.title,
//     required this.buttonText,
//     required this.type,
//     required this.skipAfterSecond,
//     required this.active,
//   });

//   static MyVideoAdModel? fromMap(Map<String, dynamic> data) {
//     return MyVideoAdModel(
//       videoUrl: data['videoUrl'],
//       onVideoFinishImage: data['onVideoFinishImage'],
//       promotionalLink: data['promotionalLink'],
//       title: data['title'],
//       buttonText: data['buttonText'],
//       type: data['type'],
//       skipAfterSecond: data['skipAfterSecond'],
//       active: data['active'],
//     );
//   }
// }
