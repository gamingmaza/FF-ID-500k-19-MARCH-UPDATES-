import 'package:cloud_firestore/cloud_firestore.dart';

class ChatModel {
  final String docId;
  final String buyerId, buyerName, buyerPhotoUrl;
  final String sellerId, sellerName, sellerPhotoUrl;
  final List<Map<String, dynamic>> messages;
  final String lastMessage;
  final Timestamp date;

  ChatModel({
    required this.docId,
    required this.buyerId,
    required this.buyerName,
    required this.buyerPhotoUrl,
    required this.sellerId,
    required this.sellerName,
    required this.sellerPhotoUrl,
    required this.messages,
    required this.lastMessage,
    required this.date,
  });

  static ChatModel fromSnapshot(
    String id,
    QueryDocumentSnapshot<Map<String, dynamic>> chat,
  ) {
    return ChatModel(
      docId: id,
      buyerId: chat['buyerId'],
      buyerName: chat['buyerName'],
      buyerPhotoUrl: chat['buyerPhotoUrl'],
      sellerId: chat['sellerId'],
      sellerName: chat['sellerName'],
      sellerPhotoUrl: chat['sellerPhotoUrl'],
      messages: List<Map<String, dynamic>>.from(chat['messages']),
      lastMessage: chat['lastMessage'],
      date: chat['date'],
    );
  }

  Map<String, Object?> toMap() {
    return {
      "buyerId": buyerId,
      "buyerName": buyerName,
      "buyerPhotoUrl": buyerPhotoUrl,
      "sellerId": sellerId,
      "sellerName": sellerName,
      "sellerPhotoUrl": sellerPhotoUrl,
      "messages": messages,
      "lastMessage": lastMessage,
      "date": date,
    };
  }
}
