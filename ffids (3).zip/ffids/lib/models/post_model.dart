import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ffids_dark/models/payment_model.dart';
import '../data/constants.dart';

class PostModel {
  final String id, thumbnail, imageUrl, title, description, category, authorId;
  final int? sellerContactCount;
  final num price;
  final Timestamp? date;
  final String authorPhoto, authorName;
  int status;
  PaymentResultModel? paymentResult;
  String? boughtBy;
  String? account;
  List<String> otherImages; // ✅ New field for additional images

  PostModel({
    this.paymentResult,
    this.status = 0,
    this.boughtBy,
    this.account,
    required this.id,
    required this.thumbnail,
    required this.title,
    required this.description,
    required this.category,
    required this.authorId,
    this.sellerContactCount,
    required this.price,
    required this.imageUrl,
    this.date,
    required this.authorPhoto,
    required this.authorName,
    this.otherImages = const [], // ✅ Initialize with an empty list
  });

  static PostModel fromSnapshot(
    String id,
    QueryDocumentSnapshot<Object?> post,
  ) {
    final data = post.data() as Map<String, dynamic>;
    return PostModel(
      id: id,
      title: data['title'] ?? 'Unknown',
      paymentResult: PaymentResultModel.fromMap(data['paymentResult']),
      thumbnail: data['thumbnail'] ?? '',
      boughtBy: data['boughtBy'],
      description: data['description'] ?? '',
      category: data['category'] ?? '',
      account: data['account'],
      authorId: post['authorId'],
      imageUrl: post['imageUrl'],
      date: post['date'],
      price: post['price'],
      sellerContactCount: data['sellerContactCount'] ?? 0,
      authorName: post['authorName'],
      authorPhoto: data['authorPhoto'] ?? defaultProfilePhotoUrl,
      status: data['status'] ?? 0, // ✅ Ensure 0 or 1
      otherImages: List<String>.from(data['otherImages'] ?? []),
    );
  }

  Map<String, Object?> toMap() {
    return {
      "title": title,
      "thumbnail": thumbnail,
      "description": description,
      "category": category,
      "account": account,
      "authorId": authorId,
      "status": status,
      "boughtBy": boughtBy,
      "imageUrl": imageUrl,
      "date": Timestamp.now(),
      'paymentResult': paymentResult?.toMap(),
      "price": price,
      "sellerContactCount": 0,
      "authorName": authorName,
      "authorPhoto": authorPhoto,
      "otherImages": otherImages,
    };
  }
}
