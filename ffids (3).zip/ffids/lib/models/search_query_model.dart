import 'package:flutter/material.dart';

class SearchQueryModel {
  String? queryText, category;
  RangeValues? priceRange;

  SearchQueryModel({
    this.queryText,
    this.category,
    this.priceRange,
  });

  bool hasData() => queryText != null || category != null || priceRange != null;
}
