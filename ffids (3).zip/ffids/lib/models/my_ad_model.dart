// enum MyBannerType { banner, mediumBanner, largeBanner }

// class MyAdModel {
//   final String imageUrl, promotionalLink, title;
//   final MyBannerType type;
//   final bool active;

//   MyAdModel({
//     required this.imageUrl,
//     required this.promotionalLink,
//     required this.title,
//     required this.type,
//     required this.active,
//   });

//   static MyAdModel? fromMap(Map<String, dynamic> data) {
//     return MyAdModel(
//       imageUrl: data['imageUrl'],
//       promotionalLink: data['promotionalLink'],
//       title: data['title'],
//       type: MyBannerType.values.byName(data['type'].toString()),
//       active: data['active'],
//     );
//   }
// }
