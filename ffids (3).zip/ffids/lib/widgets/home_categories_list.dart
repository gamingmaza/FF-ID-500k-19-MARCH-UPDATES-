import 'package:flutter/material.dart';

import '../data/categories.dart';
import '../data/constants.dart';
import '../screens/posts_screen.dart';

class HomeCategoriesList extends StatelessWidget {
  const HomeCategoriesList({super.key});

  @override
  Widget build(BuildContext context) {
    // final interstitialAd = Provider.of<FacebookInterstitialAdProvider>(context);
    // interstitialAd.load();
    return SizedBox(
      height: 94,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        shrinkWrap: true,
        itemCount: categories.length,
        itemBuilder: (context, index) => CategoryCard(
          imagePath: categories[index]['imagePath']!,
          title: categories[index]['name']!,
          press: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => PostsScreen(
                  postsType: categories[index]['type']!,
                  isApprovePage: false,
                ),
              ),
            );
          },
        ),
        separatorBuilder: (context, index) =>
            const SizedBox(width: defaultPadding),
      ),
    );
  }
}

class CategoryCard extends StatelessWidget {
  const CategoryCard({
    super.key,
    required this.imagePath,
    required this.title,
    required this.press,
  });

  final String imagePath, title;
  final Function press;

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Padding(
      padding: EdgeInsets.only(bottom: 12),
      child: OutlinedButton(
        onPressed: () => press(),
        style: OutlinedButton.styleFrom(
          shape: const RoundedRectangleBorder(
            borderRadius:
                BorderRadius.all(Radius.circular(defaultBorderRadius)),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(4),
          child: Column(
            children: [
              Expanded(child: Image.asset(imagePath)),
              const SizedBox(height: defaultPadding / 2),
              Text(title, style: textTheme.bodySmall)
            ],
          ),
        ),
      ),
    );
    // final boxWidth = (MediaQuery.of(context).size.shortestSide / 4) -
    //     (defaultPadding * (5 / 4));
    // return Material(
    //   color: Colors.transparent,
    //   shape: RoundedRectangleBorder(
    //     borderRadius: BorderRadius.circular(defaultBorderRadius),
    //     side: const BorderSide(color: Colors.black12),
    //   ),
    //   clipBehavior: Clip.hardEdge,
    //   child: SizedBox(
    //     width: boxWidth,
    //     child: Column(
    //       children: [
    //         SizedBox(
    //           height: boxWidth,
    //           child: Placeholder(),
    //         )
    //       ],
    //     ),
    //   ),
    // );
  }
}
