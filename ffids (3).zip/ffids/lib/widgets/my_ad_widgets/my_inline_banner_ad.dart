// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:ffids_dark/models/my_ad_model.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:url_launcher/url_launcher_string.dart';

// class MyInlineBannerAd extends StatelessWidget {
//   const MyInlineBannerAd({super.key, required this.mediumBanner});
//   final MyAdModel mediumBanner;

//   @override
//   Widget build(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
//       child: ClipRRect(
//         borderRadius: BorderRadius.circular(8),
//         child: GestureDetector(
//           onTap: () => launchUrlString(mediumBanner.promotionalLink),
//           child: SizedBox(
//             height: 128,
//             child: CachedNetworkImage(
//               imageUrl: mediumBanner.imageUrl,
//               fit: BoxFit.cover,
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
