// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:url_launcher/url_launcher_string.dart';
// import 'package:video_player/video_player.dart';

// import '../../models/my_video_ad_model.dart';

// class MyVideoAdDialog extends StatefulWidget {
//   const MyVideoAdDialog({super.key, required this.videoAd, this.controller});

//   final MyVideoAdModel videoAd;
//   final VideoPlayerController? controller;

//   @override
//   State<MyVideoAdDialog> createState() => _MyVideoAdDialogState();
// }

// class _MyVideoAdDialogState extends State<MyVideoAdDialog> {
//   bool _allowSkip = false, _videoFinished = false, _audioOn = false;
//   bool _showAudioButton = true, _showPromotionalButton = false;

//   @override
//   void initState() {
//     super.initState();
//     if (widget.controller != null) {
//       widget.controller!.setVolume(0);
//       widget.controller!.addListener(() {
//         if (!_allowSkip) {
//           if (widget.controller!.value.position.inSeconds >=
//               (widget.videoAd.skipAfterSecond)) {
//             _allowSkip = true;
//             _showPromotionalButton = true;
//             _showAudioButton = false;
//             setState(() {});
//           }
//         }
//         if (widget.controller!.value.position ==
//             widget.controller!.value.duration) {
//           setState(() => _videoFinished = true);
//         }
//       });
//       widget.controller!.play();
//     }
//   }

//   @override
//   void dispose() {
//     super.dispose();
//     widget.controller?.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return PopScope(
//       canPop: false,
//       child: Material(
//         color: Theme.of(context).scaffoldBackgroundColor,
//         child: _videoFinished || widget.controller == null
//             ? buildAdWhenFinished(context)
//             : widget.controller!.value.isInitialized
//                 ? buildAdShowing(context)
//                 : const Center(child: Text("Ad Loading...")),
//       ),
//     );
//   }

//   Stack buildAdShowing(BuildContext context) {
//     return Stack(
//       fit: StackFit.expand,
//       children: [
//         Center(
//           child: AspectRatio(
//             aspectRatio: widget.controller!.value.aspectRatio,
//             child: VideoPlayer(widget.controller!),
//           ),
//         ),
//         Column(
//           children: [
//             if (_allowSkip)
//               Align(
//                 alignment: Alignment.centerRight,
//                 child: TextButton.icon(
//                   onPressed: () {
//                     widget.controller!
//                         .seekTo(widget.controller!.value.duration);
//                   },
//                   style: TextButton.styleFrom(foregroundColor: Colors.white),
//                   label: const Icon(Icons.double_arrow_rounded),
//                   icon: const Text("Skip"),
//                 ),
//               ),
//             const Spacer(),
//             SizedBox(
//               height: 48,
//               child: Row(
//                 crossAxisAlignment: CrossAxisAlignment.end,
//                 children: [
//                   const SizedBox(width: 8),
//                   if (_showAudioButton) buildAudioToggle(),
//                   const Spacer(),
//                   buildPromotionalButton(),
//                   const SizedBox(width: 16),
//                 ],
//               ),
//             ),
//             const SizedBox(height: 24),
//             VideoProgressIndicator(
//               widget.controller!,
//               allowScrubbing: false,
//               colors: const VideoProgressColors(
//                 playedColor: Colors.white,
//                 backgroundColor: Colors.white10,
//               ),
//               padding: EdgeInsets.zero,
//             ),
//           ],
//         )
//       ],
//     );
//   }

//   Padding buildAdWhenFinished(BuildContext context) {
//     return Padding(
//       padding: const EdgeInsets.all(16),
//       child: Stack(
//         children: [
//           Column(
//             children: [
//               Expanded(
//                 child: Center(
//                   child: ClipRRect(
//                     borderRadius: BorderRadius.circular(16),
//                     child: CachedNetworkImage(
//                       imageUrl: widget.videoAd.onVideoFinishImage,
//                     ),
//                   ),
//                 ),
//               ),
//               const SizedBox(height: 32),
//               Text(
//                 widget.videoAd.title,
//                 style: const TextStyle(
//                   fontSize: 32,
//                   fontWeight: FontWeight.bold,
//                 ),
//                 textAlign: TextAlign.left,
//               ),
//               Padding(
//                 padding: const EdgeInsets.symmetric(vertical: 32),
//                 child: GestureDetector(
//                   onTap: () => launchUrlString(widget.videoAd.promotionalLink),
//                   child: Container(
//                     height: 48,
//                     decoration: BoxDecoration(
//                       color: Colors.blue,
//                       borderRadius: BorderRadius.circular(12),
//                     ),
//                     child: Center(
//                       child: Text(
//                         widget.videoAd.buttonText,
//                         style: const TextStyle(
//                           fontSize: 16,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ),
//                   ),
//                 ),
//               ),
//             ],
//           ),
//           Positioned(
//             top: 8,
//             left: 8,
//             child: ClipRRect(
//               borderRadius: BorderRadius.circular(24),
//               child: ColoredBox(
//                 color: Colors.black12,
//                 child: IconButton(
//                   onPressed: () => Navigator.pop(context),
//                   icon: const Icon(Icons.clear_rounded),
//                 ),
//               ),
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   ClipRRect buildAudioToggle() {
//     return ClipRRect(
//       borderRadius: BorderRadius.circular(8),
//       child: SizedBox.square(
//         dimension: 32,
//         child: ColoredBox(
//           color: Colors.white30,
//           child: IconButton(
//             onPressed: () {
//               _audioOn = !_audioOn;
//               widget.controller!.setVolume(_audioOn ? 1.0 : 0.0);
//               setState(() {});
//             },
//             icon: Icon(
//               _audioOn ? Icons.volume_up_rounded : Icons.volume_off_rounded,
//             ),
//             iconSize: 16,
//             splashRadius: 16,
//           ),
//         ),
//       ),
//     );
//   }

//   Widget buildPromotionalButton() {
//     return AnimatedScale(
//       scale: _showPromotionalButton ? 1 : 0,
//       duration: const Duration(milliseconds: 200),
//       child: ElevatedButton(
//         onPressed: () => launchUrlString(widget.videoAd.promotionalLink),
//         style: ElevatedButton.styleFrom(
//           fixedSize: const Size(100, 48),
//           backgroundColor: Colors.white,
//           textStyle: const TextStyle(fontSize: 16),
//           shape: RoundedRectangleBorder(
//             borderRadius: BorderRadius.circular(12),
//           ),
//         ),
//         child: Text(widget.videoAd.buttonText),
//       ),
//     );
//   }
// }
