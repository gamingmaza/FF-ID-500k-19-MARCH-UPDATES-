// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:ffids_dark/models/my_ad_model.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:url_launcher/url_launcher_string.dart';

// class MyBannerAd extends StatelessWidget {
//   const MyBannerAd({super.key, required this.largeBanner});
//   final MyAdModel largeBanner;

//   @override
//   Widget build(BuildContext context) {
//     // var largeBanner = Provider.of<MyAdProvider>(context).largeBanner;
//     // if (largeBanner != null) {
//     return Padding(
//       padding: const EdgeInsets.all(8),
//       child: ClipRRect(
//         borderRadius: BorderRadius.circular(4),
//         child: GestureDetector(
//           onTap: () => launchUrlString(largeBanner.promotionalLink),
//           child: AspectRatio(
//             aspectRatio: 16 / 9,
//             child: CachedNetworkImage(
//               imageUrl: largeBanner.imageUrl,
//               fit: BoxFit.cover,
//             ),
//           ),
//         ),
//       ),
//     );
//     // } else {
//     //   return const SizedBox();
//     // }
//   }
// }
