// import 'package:flutter/material.dart';

// class BannerAds extends StatelessWidget {
//   const BannerAds({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       alignment: const Alignment(0.5, 1),
//       // child: FacebookBannerAd(
//       //   placementId: "2082563042104269_2082564465437460",
//       //   bannerSize: BannerSize.STANDARD,
//       //   listener: (result, value) {
//       //     switch (result) {
//       //       case BannerAdResult.ERROR:
//       //         print("Error: $value");
//       //         break;
//       //       case BannerAdResult.LOADED:
//       //         print("Loaded: $value");
//       //         break;
//       //       case BannerAdResult.CLICKED:
//       //         print("Clicked: $value");
//       //         break;
//       //       case BannerAdResult.LOGGING_IMPRESSION:
//       //         print("Logging Impression: $value");
//       //         break;
//       //     }
//       //   },
//       // ),
//     );
//   }
// }
