import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class PostStatusWidget extends StatelessWidget {
  final Map<String, dynamic> postData;
  final bool isAdminView;

  const PostStatusWidget({
    Key? key,
    required this.postData,
    this.isAdminView = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    int status = postData['status'] ?? 0;
    double price = (postData['price'] ?? 0).toDouble();
    String title = postData['title'] ?? "Unknown Title";
    String thumbnail = postData['thumbnail'] ?? "";

    if (status == 1) {
      // Approved UI
      return Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        clipBehavior: Clip.hardEdge,
        child: InkWell(
          onTap: () {
            // Navigate to details screen (if needed)
          },
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: SizedBox(
              height: 94,
              child: Row(
                children: [
                  AspectRatio(
                    aspectRatio: 16 / 9,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: CachedNetworkImage(
                        imageUrl: thumbnail,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      children: [
                        Expanded(
                          child: Center(
                            child: Text(
                              title,
                              maxLines: 3,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Text(
                            "Approved - \$${price.toStringAsFixed(2)}",
                            style: TextStyle(
                                color: Colors.green,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    } else {
      // Pending UI (Admin Action Required)
      return Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 5),
              Text("Pending - \$$price",
                  style: TextStyle(color: Colors.orange)),
              SizedBox(height: 10),
              Container(
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade300),
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: EdgeInsets.all(8),
                child:
                    Text(postData.toString()), // Show JSON Data (as in image)
              ),
              SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  ElevatedButton(
                    style:
                        ElevatedButton.styleFrom(backgroundColor: Colors.green),
                    onPressed: () {
                      // Handle Approve Action
                    },
                    child: Text("Approve"),
                  ),
                  ElevatedButton(
                    style:
                        ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    onPressed: () {
                      // Handle Reject Action
                    },
                    child: Text("Reject"),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }
  }
}
