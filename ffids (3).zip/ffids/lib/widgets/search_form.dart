import 'package:chips_choice/chips_choice.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../data/categories.dart';
import '../data/constants.dart';
import '../models/search_query_model.dart';
import 'my_submit_button.dart';

const OutlineInputBorder outlineInputBorder = OutlineInputBorder(
  borderRadius: BorderRadius.all(Radius.circular(12)),
  borderSide: BorderSide.none,
);

class SearchForm extends StatefulWidget {
  const SearchForm({
    super.key,
    required this.onSearch,
    this.initialValue,
  });

  final SearchQueryModel? initialValue;
  final Function(SearchQueryModel) onSearch;

  @override
  State<SearchForm> createState() => _SearchFormState();
}

class _SearchFormState extends State<SearchForm> {
  late SearchQueryModel queryModel;
  @override
  void initState() {
    queryModel = widget.initialValue ?? SearchQueryModel();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      child: TextFormField(
        initialValue: queryModel.queryText,
        decoration: InputDecoration(
          hintText: "Search",
          filled: true,
          fillColor: Colors.white,
          prefixIcon: Padding(
            padding: const EdgeInsets.all(14),
            child: SvgPicture.asset("assets/svg/Search.svg"),
          ),
          suffixIcon: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(
                  horizontal: defaultPadding,
                  vertical: defaultPadding / 2,
                ),
                child: SizedBox(
                  width: 48,
                  height: 48,
                  child: ElevatedButton(
                    onPressed: () => onFilterPressed(
                      context,
                      (searchQuery) {
                        queryModel.category = searchQuery.category;
                        queryModel.priceRange = searchQuery.priceRange;
                        setState(() {});
                      },
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primaryColor,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(12)),
                      ),
                    ),
                    child: SvgPicture.asset("assets/svg/filter.svg"),
                  ),
                ),
              ),
              if (queryModel.category != null || queryModel.priceRange != null)
                Positioned(
                  right: defaultPadding / 1.5,
                  top: defaultPadding / 3,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: primaryColor,
                      border: Border.all(color: Colors.white, width: 2),
                    ),
                    child: const SizedBox.square(dimension: 14),
                  ),
                ),
            ],
          ),
          border: outlineInputBorder,
          enabledBorder: outlineInputBorder,
          focusedBorder: outlineInputBorder,
          errorBorder: outlineInputBorder,
        ),
        onFieldSubmitted: (value) {
          queryModel.queryText = value.isNotEmpty ? value : null;
          if (queryModel.hasData()) widget.onSearch(queryModel);
        },
        textInputAction: TextInputAction.search,
        style: Theme.of(context).textTheme.labelLarge,
      ),
    );
  }

  void onFilterPressed(
      BuildContext context, Function(SearchQueryModel) onApply) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(defaultBorderRadius * 2),
        ),
      ),
      clipBehavior: Clip.hardEdge,
      builder: (_) =>
          SearchFormFilter(initialValue: queryModel, onApply: onApply),
    );
  }
}

class SearchFormFilter extends StatefulWidget {
  const SearchFormFilter({
    super.key,
    required this.onApply,
    required this.initialValue,
  });
  final SearchQueryModel? initialValue;
  final Function(SearchQueryModel) onApply;

  @override
  State<SearchFormFilter> createState() => _SearchFormFilterState();
}

class _SearchFormFilterState extends State<SearchFormFilter> {
  late SearchQueryModel queryModel;

  @override
  void initState() {
    queryModel = widget.initialValue ?? SearchQueryModel();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Wrap(
      children: [
        SizedBox(
          height: 64,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                width: 64,
                child: TextButton(
                  onPressed: () {
                    setState(() {
                      queryModel.category = null;
                      queryModel.priceRange = null;
                    });
                    widget.onApply(queryModel);
                  },
                  child: const Text("Clear"),
                ),
              ),
              Text("Filters", style: textTheme.titleLarge),
              SizedBox(
                width: 64,
                child: IconButton(
                  onPressed: () => Navigator.pop(context),
                  splashRadius: 24,
                  iconSize: 24,
                  icon: const Icon(Icons.clear_rounded),
                ),
              ),
            ],
          ),
        ),
        const Divider(height: 0),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(
                top: defaultPadding,
                left: defaultPadding,
              ),
              child: Text("Category", style: textTheme.titleLarge),
            ),
            ChipsChoice.single(
              value: queryModel.category ?? '',
              choiceStyle: C2ChipStyle(
                foregroundStyle: Theme.of(context).textTheme.labelLarge,
                foregroundColor: primaryColor,
                borderRadius: BorderRadius.circular(defaultBorderRadius),
                height: 40,
              ),
              choiceCheckmark: true,
              choiceItems: categories
                  .map((e) => C2Choice(value: e['tag'], label: e['name']))
                  .toList(),
              onChanged: (v) => setState(() => queryModel.category = v),
            ),
            const SizedBox(height: defaultPadding),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: defaultPadding),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Pricing", style: textTheme.titleLarge),
                  Text(
                    "\$${queryModel.priceRange?.start.toInt() ?? 0} - \$${queryModel.priceRange?.end.toInt() ?? 1000}",
                    style: textTheme.titleSmall,
                  )
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(defaultPadding),
              child: RangeSlider(
                min: 0,
                max: 1000,
                values: queryModel.priceRange ?? const RangeValues(0, 1000),
                onChanged: (value) {
                  setState(() => queryModel.priceRange = value);
                },
                activeColor: primaryColor,
                inactiveColor: Colors.black38,
                divisions: 1000,
                labels: RangeLabels(
                  '${queryModel.priceRange?.start.toInt() ?? 0}',
                  '${queryModel.priceRange?.end.toInt() ?? 1000}',
                ),
              ),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.all(defaultPadding),
          child: Center(
            child: MySubmitButton(
              label: "Apply",
              onPressed: () {
                widget.onApply(queryModel);
                Navigator.pop(context);
              },
            ),
          ),
        ),
      ],
    );
  }
}
