import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import '../data/constants.dart';
import '../services/auth_service.dart';

class ContinueWithGoogleButton extends StatefulWidget {
  const ContinueWithGoogleButton({super.key});

  @override
  State<ContinueWithGoogleButton> createState() =>
      _ContinueWithGoogleButtonState();
}

class _ContinueWithGoogleButtonState extends State<ContinueWithGoogleButton> {
  bool _isLoading = false;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFFF2F2F2),
      borderRadius: BorderRadius.circular(32),
      clipBehavior: Clip.hardEdge,
      child: InkWell(
        onTap: () async {
          if (_isLoading) return;
          if (mounted) setState(() => _isLoading = true);
          await AuthService.loginWithGoogle();
          if (mounted) setState(() => _isLoading = false);
        },
        child: SizedBox(
          height: 64,
          width: _isLoading ? 64 : null,
          child: Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: _isLoading
                ? const Center(child: CircularProgressIndicator(strokeWidth: 3))
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SvgPicture.asset("assets/svg/google.svg"),
                      const SizedBox(width: defaultPadding / 2),
                      const Text("Continue with Google"),
                      const SizedBox(width: defaultPadding / 2),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}
