import 'package:cached_network_image/cached_network_image.dart';
import 'package:ffids_dark/extentions/my_num.dart';
import 'package:flutter/material.dart';
import '../data/constants.dart';
import '../models/post_model.dart';
import '../screens/detail_screen.dart';

class PostsCard extends StatefulWidget {
  const PostsCard({
    super.key,
    required this.postModel,
    // required this.showInertialAd,
  });
  final PostModel postModel;

  @override
  State<PostsCard> createState() => _PostsCardState();
}

class _PostsCardState extends State<PostsCard> {
  // final Function showInertialAd;
  // final adController = InterstitialAdController();

  @override
  void initState() {
    // adController.load();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return Material(
      color: Colors.white,
      borderRadius: const BorderRadius.all(
        Radius.circular(defaultBorderRadius),
      ),
      clipBehavior: Clip.hardEdge,
      child: InkWell(
        onTap: () async {
          // bool value = await getValueFromKey();
          // if (value) {
          //   log("Add Showing On Each Post Click Alwed Showing Ad");
          //   // adController.show();
          // } else {
          //   log("Add Showing On Each Post Click Not Allowed");
          // }
          // await showInertialAd();
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => DetailScreen(postModel: widget.postModel),
            ),
          );
        },
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 10),
          child: Container(
            width: 160 + defaultPadding,
            padding: const EdgeInsets.all(defaultPadding / 2),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(defaultBorderRadius),
                  child: CachedNetworkImage(
                    imageUrl: widget.postModel.thumbnail,
                    height: 115,
                    width: MediaQuery.of(context).size.width * 0.5,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(height: defaultPadding / 2),
                SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        widget.postModel.title,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 3,
                        style: TextStyle(
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(width: defaultPadding / 4),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Padding(
                          padding: EdgeInsets.only(right: 20),
                          child: Text(
                            "\$${widget.postModel.price.priceFormat()}",
                            style: textTheme.titleSmall,
                            textAlign: TextAlign.right,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
