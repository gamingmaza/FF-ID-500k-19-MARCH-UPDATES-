import 'package:flutter/material.dart';

import '../data/constants.dart';

class ContactButtonController {
  late VoidCallback startLoading, stopLoading;

  void dispose() {
    // startLoading = stopLoading = null;
  }
}

class ContactButton extends StatefulWidget {
  const ContactButton({
    super.key,
    required this.onPressed,
    this.controller,
  });

  final VoidCallback onPressed;
  final ContactButtonController? controller;

  @override
  State<ContactButton> createState() => _ContactButtonState();
}

class _ContactButtonState extends State<ContactButton> {
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.controller != null) {
      widget.controller!.startLoading = () {
        if (mounted) {
          setState(() => isLoading = true);
        }
      };
      widget.controller!.stopLoading = () {
        if (mounted) {
          setState(() => isLoading = false);
        }
      };
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox.square(
      dimension: 64,
      child: Material(
        color: primaryColor,
        borderRadius: BorderRadius.circular(64),
        clipBehavior: Clip.hardEdge,
        child: InkWell(
          onTap: widget.onPressed,
          child: Center(
            child: isLoading
                ? const SizedBox.square(
                    dimension: 32,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 3,
                    ),
                  )
                : const Icon(
                    Icons.message_outlined,
                    size: 32,
                    color: Colors.white,
                  ),
          ),
        ),
      ),
    );
  }
}
