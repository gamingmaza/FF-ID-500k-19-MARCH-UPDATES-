import 'dart:developer' as show;
import 'package:ffids_dark/core/admob_ad_ids.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../data/constants.dart';
import '../data/posts_type.dart';
import '../models/post_model.dart';
import '../services/firestore_service.dart';
import 'posts_card.dart';

class HomePostsList extends StatelessWidget {
  final BannerAdWidget bannerAdWidget = BannerAdWidget();
  HomePostsList({super.key, required this.title, required this.postsType});

  final String title;
  final PostsType postsType;
  final List<int> adPattern = [3, 5, 7, 5, 5, 5, 5]; // Ad insertion pattern

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<(List<PostModel>?, dynamic)>(
      future: FirestoreService.fetchPostsByType(postsType, null),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          final posts = snapshot.data?.$1;
          if (posts != null && posts.isNotEmpty) {
            List<dynamic> displayItems = insertAds(posts);

            return ListView.separated(
              physics: NeverScrollableScrollPhysics(),
              itemCount: displayItems.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                var item = displayItems[index];
                if (item is PostModel) {
                  return PostsCard(postModel: item);
                } else {
                  return bannerAdWidget; // Insert Ad Widget
                }
              },
              separatorBuilder: (_, __) =>
                  const SizedBox(height: defaultPadding),
            );
          } else {
            return const Center(child: Text("No Data Found"));
          }
        } else if (snapshot.hasError) {
          return Center(
              child:
                  Text(snapshot.error.toString(), textAlign: TextAlign.center));
        } else {
          return const Center(child: CircularProgressIndicator());
        }
      },
    );
  }

  /// Inserts ads based on the specified pattern
  List<dynamic> insertAds(List<PostModel> posts) {
    List<dynamic> displayItems = [];
    int index = 0;
    int patternIndex = 0;

    while (index < posts.length) {
      int interval = patternIndex < adPattern.length
          ? adPattern[patternIndex]
          : 5; // Default to 5 after pattern ends
      int endIndex = (index + interval).clamp(0, posts.length);

      displayItems.addAll(posts.sublist(index, endIndex));
      index = endIndex;
      patternIndex++;

      if (index < posts.length) {
        displayItems.add("Ad"); // Placeholder for the Ad Widget
      }
    }
    return displayItems;
  }
}

class BannerAdWidget extends StatefulWidget {
  const BannerAdWidget({super.key});

  @override
  State<BannerAdWidget> createState() => _BannerAdWidgetState();
}

class _BannerAdWidgetState extends State<BannerAdWidget> {
  BannerAd? _bannerAd;

  @override
  void initState() {
    super.initState();
    _loadBannerAd();
  }

  void _loadBannerAd() {
    _bannerAd = BannerAd(
      adUnitId: AdxIds.adxBannerAdID, // ✅ Use your AdX Banner ID
      size: AdSize.largeBanner,
      request: const AdManagerAdRequest(), // ✅ Use AdManagerAdRequest() for AdX
      listener: BannerAdListener(
        onAdLoaded: (_) {
          show.log("✅ Banner Ad Loaded Successfully");
          setState(() {}); // Update UI
        },
        onAdFailedToLoad: (ad, error) {
          show.log("❌ Banner Ad Failed to Load: ${error.message}");
          ad.dispose();
          setState(() => _bannerAd = null); // Clear ad reference
        },
      ),
    )..load();
  }

  @override
  Widget build(BuildContext context) {
    return _bannerAd != null
        ? SizedBox(height: 100, child: AdWidget(ad: _bannerAd!))
        : const Center(child: Text("Advertisement"));
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }
}
