// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:ffids_dark/extentions/my_num.dart';
// import 'package:flutter/material.dart';

// import '../data/constants.dart';
// import '../models/post_model.dart';
// import '../screens/detail_screen.dart';

// class PostsListTile extends StatelessWidget {
//   const PostsListTile({
//     super.key,
//     required this.postModel,
//     this.isAdminView = false,
//   });
//   final bool isAdminView;
//   final PostModel postModel;

//   @override
//   Widget build(BuildContext context) {
//     final textTheme = Theme.of(context).textTheme;

//     return Material(
//       color: Colors.white,
//       borderRadius: BorderRadius.circular(defaultBorderRadius),
//       clipBehavior: Clip.hardEdge,
//       child: InkWell(
//         onTap: () {
//           // showAdFunction();
//           Navigator.push(
//               context,
//               MaterialPageRoute(
//                 builder: (context) => DetailScreen(
//                   postModel: postModel,
//                 ),
//               ));
//         },
//         child: Padding(
//           padding: const EdgeInsets.all(defaultPadding),
//           child: SizedBox(
//             height: 94,
//             child: Row(
//               children: [
//                 AspectRatio(
//                   aspectRatio: 16 / 9,
//                   child: ClipRRect(
//                     borderRadius: BorderRadius.circular(defaultBorderRadius),
//                     child: CachedNetworkImage(
//                       imageUrl: postModel.thumbnail,
//                       fit: BoxFit.cover,
//                     ),
//                   ),
//                 ),
//                 const SizedBox(width: defaultPadding / 2),
//                 Expanded(
//                   child: Column(
//                     children: [
//                       Expanded(
//                         child: Center(
//                           child: Text(
//                             postModel.title,
//                             maxLines: 3,
//                             overflow: TextOverflow.ellipsis,
//                           ),
//                         ),
//                       ),
//                       Align(
//                         alignment: Alignment.centerRight,
//                         child: Text(
//                           "${isAdminView ? postModel.status == 0 ? "Pending" : postModel.status == 1 ? "Approved" : "Rejected" : ""}${isAdminView ? " - " : ''}\$${postModel.price.priceFormat()}",
//                           style: textTheme.titleSmall,
//                         ),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
import 'dart:developer' show log;

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ffids_dark/extentions/my_num.dart';
import 'package:ffids_dark/screens/bought_product_details_page.dart';
import 'package:flutter/material.dart';
import '../data/constants.dart';
import '../models/post_model.dart';
import '../screens/detail_screen.dart';

class PostsListTile extends StatelessWidget {
  PostsListTile({
    super.key,
    required this.postModel,
    this.isAdminView = false,
    this.onApprove,
    this.onReject,
    this.onRevert,
  });

  final bool isAdminView;
  final PostModel postModel;
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final VoidCallback? onApprove;
  final VoidCallback? onReject;
  final VoidCallback? onRevert;

  @override
  Widget build(BuildContext context) {
    log(postModel.id);
    final textTheme = Theme.of(context).textTheme;

    if (postModel.status == 0 && isAdminView) {
      // Pending UI (First Image with Approve & Reject Buttons)
      return Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(defaultBorderRadius),
        clipBehavior: Clip.hardEdge,
        child: Padding(
          padding: const EdgeInsets.all(defaultPadding),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(postModel.title, style: textTheme.titleMedium),
              const SizedBox(height: 8),
              LabelValueText(
                  label: "Name", value: postModel.paymentResult?.name ?? "N/A"),
              LabelValueText(
                  label: "User", value: postModel.paymentResult?.user ?? "N/A"),
              LabelValueText(
                  label: "UID", value: postModel.paymentResult?.uid ?? "N/A"),
              LabelValueText(
                  label: "ProductID",
                  value: postModel.paymentResult?.productID ?? "N/A"),
              LabelValueText(
                  label: "PurchaseID",
                  value: postModel.paymentResult?.purchaseId ?? "N/A"),
              LabelValueText(
                  label: "TranscationDate",
                  value: postModel.paymentResult?.transactionDate ?? "N/A"),
              LabelValueText(
                  label: "ErrorSource",
                  value: postModel.paymentResult?.errorSource ?? "N/A"),
              LabelValueText(
                  label: "ErrorCode",
                  value: postModel.paymentResult?.errorCode ?? "N/A"),
              LabelValueText(
                  label: "ErrorMessage",
                  value: postModel.paymentResult?.errorMessage ?? "N/A"),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: onApprove,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                      ),
                      child: const Text("Approve"),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: onReject,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                      ),
                      child: const Text("Reject"),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                "Pending - \$${postModel.price}",
                style: textTheme.titleSmall,
              ),
            ],
          ),
        ),
      );
    } else if (postModel.status == 1 ||
        (postModel.status == 0 && !isAdminView)) {
      // Approved UI (Second Image Style)
      return Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(defaultBorderRadius),
        clipBehavior: Clip.hardEdge,
        child: InkWell(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => !isAdminView
                      ? DetailScreen(postModel: postModel)
                      : BoughtAccountDetailPage(
                          postModel: postModel,
                          onRevert: onRevert,
                        ),
                ));
          },
          child: Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: SizedBox(
              height: 94,
              child: Row(
                children: [
                  AspectRatio(
                    aspectRatio: 16 / 9,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(defaultBorderRadius),
                      child: CachedNetworkImage(
                        imageUrl: postModel.thumbnail,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  const SizedBox(width: defaultPadding / 2),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            postModel.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: textTheme.titleMedium,
                          ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: Text(
                            "${isAdminView ? postModel.status == 0 ? "Pending" : postModel.status == 1 ? "Approved" : "Rejected" : ""}${isAdminView ? " - " : ''}\$${postModel.price.priceFormat()}",
                            style: textTheme.titleSmall,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    } else {
      return Container(); // Handle other statuses (if needed)
    }
  }
}

class LabelValueText extends StatelessWidget {
  final String label;
  final String value;
  final double? fontsize;
  final double? padding;
  const LabelValueText({
    Key? key,
    required this.label,
    required this.value,
    this.fontsize,
    this.padding,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 4, horizontal: padding ?? 0),
      child: RichText(
        text: TextSpan(
          style: TextStyle(fontSize: fontsize ?? 14, color: Colors.black),
          children: [
            TextSpan(
              text: '$label: ',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            TextSpan(
              text: value.isNotEmpty ? value : "N/A",
              style: TextStyle(
                  fontWeight: FontWeight.normal,
                  fontSize: fontsize == null ? 12 : (fontsize! - 2)),
            ),
          ],
        ),
      ),
    );
  }
}
