import 'package:flutter/material.dart';

import '../data/constants.dart';

class MySubmitButtonController {
  late VoidCallback startLoading, stopLoading;

  void dispose() {
    // startLoading = stopLoading = null;
  }
}

class MySubmitButton extends StatefulWidget {
  const MySubmitButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.controller,
    this.backgroundColor,
  });

  final String label;
  final VoidCallback onPressed;
  final MySubmitButtonController? controller;
  final Color? backgroundColor;

  @override
  State<MySubmitButton> createState() => _MySubmitButtonState();
}

class _MySubmitButtonState extends State<MySubmitButton> {
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    if (widget.controller != null) {
      widget.controller!.startLoading = () {
        if (mounted) {
          setState(() => isLoading = true);
        }
      };
      widget.controller!.stopLoading = () {
        if (mounted) {
          setState(() => isLoading = false);
        }
      };
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.6,
      height: 64,
      child: Material(
        color: widget.backgroundColor ?? primaryColor,
        borderRadius: BorderRadius.circular(64),
        clipBehavior: Clip.hardEdge,
        child: InkWell(
          onTap: widget.onPressed,
          child: Center(
            child: isLoading
                ? const SizedBox.square(
                    dimension: 32,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 3,
                    ),
                  )
                : Text(
                    widget.label,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w500,
                      color: Colors.white,
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
