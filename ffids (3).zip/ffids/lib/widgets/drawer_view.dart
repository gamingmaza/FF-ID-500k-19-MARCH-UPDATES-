import 'package:cached_network_image/cached_network_image.dart';
import 'package:ffids_dark/providers/auth.dart';
import 'package:ffids_dark/screens/upload_banner_ad_info.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher_string.dart';

import '../data/constants.dart';
import '../data/posts_type.dart';
import '../screens/favourite_posts_screen.dart';
import '../screens/posts_screen.dart';
import '../services/auth_service.dart';
import 'drawer_listtile.dart';
import 'package:ffids_dark/services/firestore_service.dart';

class DrawerView extends StatelessWidget {
  const DrawerView({super.key});

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    return StreamBuilder(
      stream: Provider.of<UserStateProvider>(context).currentUser,
      builder: (context, userState) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: SizedBox(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 36,
                        backgroundColor: Colors.white,
                        backgroundImage: CachedNetworkImageProvider(
                          userState.data?.photoURL ?? defaultProfilePhotoUrl,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              userState.data?.displayName ?? "Guest User",
                              style: textTheme.bodyLarge,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                            Text(
                              userState.data?.email ?? "---",
                              style: textTheme.bodySmall,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                          ],
                        ),
                      ),
                      // const Icon(Icons.arrow_forward_ios_rounded),
                      const SizedBox(width: defaultPadding)
                    ],
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        DrawerListTile(
                          label: "My Ids",
                          icon: const Icon(Icons.format_list_numbered_rounded),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  const PostsScreen(postsType: PostsType.myIds),
                            ),
                          ),
                        ),

                        DrawerListTile(
                          label: "Purchases",
                          icon: const Icon(Icons.star),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => PostsScreen(
                                postsType: PostsType.hasBought,
                                reference: FirestoreService.bought,
                              ),
                            ),
                          ),
                        ),
                        if (AuthService().user?.email ==
                                "ahreftooltechonway@gmail.com" ||
                            AuthService().user?.email ==
                                "codewithmnasir@gmail.com")
                          //"mustafalada36pubg@gmail.com")
                          DrawerListTile(
                            label: "Need Review",
                            icon: const Icon(Icons.local_police),
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => PostsScreen(
                                  postsType: PostsType.admin,
                                  reference: FirestoreService.bought,
                                  isApprovePage: true,
                                ),
                              ),
                            ),
                          ),
                        if (AuthService().user?.email ==
                                "codewithmnasir@gmail.com" ||
                            AuthService().user?.email ==
                                "ahreftooltechonway@gmail.com")
                          DrawerListTile(
                            label: "Upload Banner Ad",
                            icon: const Icon(Icons.ad_units_rounded),
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) =>
                                    const UploadBannerAdInfo(),
                              ),
                            ),
                          ),
                        DrawerListTile(
                          label: "Favourites",
                          icon: const Icon(Icons.favorite_rounded),
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  const FavouritePostsScreen(),
                            ),
                          ),
                        ),
                        DrawerListTile(
                          label: "Privacy Policy",
                          icon: const Icon(Icons.policy_rounded),
                          onTap: () => launchUrlString(privacyPolicyUrl),
                        ),
                        DrawerListTile(
                          label: "Terms",
                          icon: const Icon(Icons.handshake_rounded),
                          onTap: () => launchUrlString(termsUrl),
                        ),
                        // DrawerListTile(
                        //   label: "About Us",
                        //   icon: const Icon(Icons.groups_rounded),
                        //   onTap: () {},
                        // ),
                      ],
                    ),
                  ),
                  if (userState.data == null)
                    DrawerListTile(
                      label: "Login",
                      icon: const Icon(Icons.person_rounded),
                      onTap: () => Navigator.popUntil(
                        context,
                        ModalRoute.withName('/'),
                      ),
                    )
                  else
                    DrawerListTile(
                      label: "Logout",
                      icon: const Icon(Icons.power_settings_new_rounded),
                      onTap: () => AuthService.logout().then(
                        (value) => Navigator.popUntil(
                          context,
                          ModalRoute.withName('/'),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
