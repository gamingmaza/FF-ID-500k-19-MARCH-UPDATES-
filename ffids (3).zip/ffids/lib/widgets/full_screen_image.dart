import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class FullScreenImage extends StatelessWidget {
  const FullScreenImage({
    super.key,
    required this.imageUrl,
  });

  final String imageUrl;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(
              Icons.keyboard_backspace_rounded,
              color: Colors.white,
            ),
          ),
        ),
        body:
            // PageView.builder(
            //   controller: PageController(initialPage: index),
            //   itemCount: imageUrls.length,
            //   itemBuilder: (context, index) {
            //     return
            Center(
          child: InteractiveViewer(
            child: Hero(
              tag: "image",
              child: CachedNetworkImage(imageUrl: imageUrl),
            ),
          ),
        )
        // ;
        //   },
        // ),
        );
  }
}
