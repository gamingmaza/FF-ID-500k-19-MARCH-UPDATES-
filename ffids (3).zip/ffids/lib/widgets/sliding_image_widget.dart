// ignore_for_file: unnecessary_null_comparison

import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:ffids_dark/models/post_model.dart';
import 'package:ffids_dark/widgets/full_screen_image.dart';

class SlidingImageWidget extends StatefulWidget {
  final PostModel postModel;

  const SlidingImageWidget({Key? key, required this.postModel})
      : super(key: key);

  @override
  _SlidingImageWidgetState createState() => _SlidingImageWidgetState();
}

class _SlidingImageWidgetState extends State<SlidingImageWidget> {
  late final PageController _pageController;
  late final List<String> _imageUrls;
  int _currentPage = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _imageUrls = [
      widget.postModel.imageUrl,
      if (widget.postModel.otherImages != null) ...widget.postModel.otherImages,
    ];

    _pageController = PageController();

    if (_imageUrls.length > 1) {
      _startAutoScroll();
    }
  }

  void _startAutoScroll() {
    _timer = Timer.periodic(const Duration(seconds: 3), (timer) {
      if (!mounted) return;
      setState(() {
        _currentPage = (_currentPage + 1) % _imageUrls.length;
      });
      _pageController.animateToPage(
        _currentPage,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  void _openFullScreenImage(String imageUrl) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => FullScreenImage(imageUrl: imageUrl),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: AspectRatio(
        aspectRatio: 16 / 9,
        child: Stack(
          children: [
            Hero(
              tag:
                  "image-${_imageUrls[_currentPage]}", // Unique tag for animation
              child: GestureDetector(
                onTap: () => _openFullScreenImage(_imageUrls[_currentPage]),
                child: PageView.builder(
                  controller: _pageController,
                  itemCount: _imageUrls.length,
                  onPageChanged: (index) {
                    setState(() {
                      _currentPage = index;
                    });
                  },
                  itemBuilder: (context, index) {
                    return CachedNetworkImage(
                      imageUrl: _imageUrls[index],
                      fit: BoxFit.cover,
                      placeholder: (context, url) => const ColoredBox(
                        color: Colors.black12,
                      ),
                    );
                  },
                ),
              ),
            ),

            // Positioned Widget for Image Counter
            Positioned(
              bottom: 8,
              right: 12,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Text(
                  "${_currentPage + 1} / ${_imageUrls.length}",
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
