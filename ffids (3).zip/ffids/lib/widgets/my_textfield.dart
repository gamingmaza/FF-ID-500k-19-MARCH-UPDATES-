import 'package:flutter/material.dart';

import '../data/constants.dart';

const OutlineInputBorder outlineInputBorder = OutlineInputBorder(
  borderRadius: BorderRadius.all(Radius.circular(12)),
  borderSide: BorderSide.none,
);

class MyTextField extends StatelessWidget {
  const MyTextField({
    super.key,
    this.initialValue,
    this.hintText,
    this.obsecureText,
    this.prefixIcon,
    this.suffixIcon,
    required this.controller,
    this.maxLines = 1,
    this.keyboardType,
  });

  final int? maxLines;
  final String? initialValue, hintText;
  final bool? obsecureText;
  final Widget? prefixIcon, suffixIcon;
  final TextEditingController controller;
  final TextInputType? keyboardType;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        hintText: hintText,
        filled: true,
        fillColor: Colors.white,
        prefixIconColor: primaryColor,
        prefixIcon: Padding(
          padding: const EdgeInsets.all(defaultPadding / 2),
          child: Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: primaryColor.withOpacity(0.05),
              borderRadius: BorderRadius.circular(defaultBorderRadius),
            ),
            child: Center(child: prefixIcon),
          ),
        ),
        suffixIconColor: Theme.of(context).iconTheme.color,
        suffixIcon: suffixIcon,
        border: outlineInputBorder,
        enabledBorder: outlineInputBorder,
        focusedBorder: outlineInputBorder,
        errorBorder: outlineInputBorder,
      ),
      obscureText: obsecureText ?? false,
      maxLines: maxLines,
      minLines: 1,
      keyboardType: keyboardType,
      style: Theme.of(context).textTheme.titleMedium?.copyWith(height: 1.4),
    );
  }
}
