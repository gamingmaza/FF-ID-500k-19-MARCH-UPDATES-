import 'package:flutter/material.dart';

import '../data/constants.dart';

class ChatBubble extends StatelessWidget {
  const ChatBubble({
    super.key,
    required this.type,
    required this.content,
    required this.isAuthor,
  });

  final String type, content;
  final bool isAuthor;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: isAuthor ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        padding: const EdgeInsets.all(14),
        margin: const EdgeInsets.symmetric(vertical: 4),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.6,
        ),
        decoration: BoxDecoration(
          color: isAuthor ? primaryColor : Colors.white,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          content,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: isAuthor ? Colors.white : null,
          ),
        ),
      ),
    );
  }
}
