import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../data/constants.dart';
import '../models/chat_model.dart';
import '../screens/chats/chat_room.dart';

class ChatTile extends StatelessWidget {
  const ChatTile({
    super.key,
    required this.chatModel,
    required this.currentUser,
    required this.onDelete,
  });

  final ChatModel chatModel;
  final User currentUser;
  final Function onDelete;

  @override
  Widget build(BuildContext context) {
    final isBuyer = chatModel.buyerId == currentUser.uid;
    return SizedBox(
      height: 96,
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(defaultBorderRadius),
        clipBehavior: Clip.hardEdge,
        child: InkWell(
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ChatRoom(
                docId: chatModel.docId,
                anotherUserId: isBuyer ? chatModel.sellerId : chatModel.buyerId,
                anotherUserName:
                    isBuyer ? chatModel.sellerName : chatModel.buyerName,
                anotherUserPhotoUrl: isBuyer
                    ? chatModel.sellerPhotoUrl
                    : chatModel.buyerPhotoUrl,
                onDelete: onDelete,
              ),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(defaultPadding),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(defaultBorderRadius),
                  child: CachedNetworkImage(
                    imageUrl: isBuyer
                        ? chatModel.sellerPhotoUrl
                        : chatModel.buyerPhotoUrl,
                    placeholder: (_, __) =>
                        const ColoredBox(color: Colors.black12),
                    errorWidget: (context, url, error) => Icon(Icons.person),
                  ),
                ),
                const SizedBox(width: defaultPadding),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Text(
                        isBuyer ? chatModel.sellerName : chatModel.buyerName,
                        style: Theme.of(context).textTheme.titleMedium,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      // const SizedBox(height: 4),
                      Text(
                        chatModel.lastMessage,
                        style: Theme.of(context).textTheme.bodySmall,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
