extension MyNum on num {
  String priceFormat() {
    return this % 1 == 0 ? toString().replaceAll('.0', '') : toString();
  }
}
