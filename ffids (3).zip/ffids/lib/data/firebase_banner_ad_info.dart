class FireBaseBannerAdInfo {
  final String imageUrl;
  final String adUrl;
  final double height;

  FireBaseBannerAdInfo({
    required this.imageUrl,
    required this.adUrl,
    required this.height,
  });

  // Factory constructor to create an object from Firestore document
  factory FireBaseBannerAdInfo.fromMap(Map<String, dynamic> map) {
    return FireBaseBannerAdInfo(
      imageUrl: map['imageUrl'] ?? '',
      adUrl: map['adUrl'] ?? '',
      height: (map['height'] ?? 0).toDouble(),
    );
  }

  // Converts the object to a map (for Firestore)
  Map<String, dynamic> toMap() {
    return {
      "imageUrl": imageUrl,
      "adUrl": adUrl,
      "height": height,
    };
  }
}
