import 'posts_type.dart';

const List<Map<String, dynamic>> categories = [
  {
    "name": "Elite Pass",
    "imagePath": "assets/images/elite_pass.png",
    "type": PostsType.elitepass,
    "tag": "elite_pass",
  },
  {
    "name": "Diamonds",
    "imagePath": "assets/images/diamond.png",
    "type": PostsType.diamonds,
    "tag": "diamonds",
  },
  {
    "name": "Gun Skins",
    "imagePath": "assets/images/gun_skins.png",
    "type": PostsType.gunskins,
    "tag": "gun_skins",
  },
  {
    "name": "Clothes",
    "imagePath": "assets/images/clothes.png",
    "type": PostsType.clothes,
    "tag": "clothes",
  },
  {
    "name": "New",
    "imagePath": "assets/images/new.png",
    "type": PostsType.newId,
    "tag": "new",
  },
];
