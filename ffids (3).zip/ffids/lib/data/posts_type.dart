enum PostsType {
  latest,
  popular,
  diamonds,
  elitepass,
  gunskins,
  clothes,
  newId,
  myIds,
  hasBought,
  admin,
}
