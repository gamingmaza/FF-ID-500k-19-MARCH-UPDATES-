import 'dart:ui';

const Color primaryColor = Color(0xFFF67952);
const Color backgroundColor = Color(0xFFFBFBFD);

/// defaultPadding = 16.0
const double defaultPadding = 16.0;

/// defaultBorderRadius = 12.0
const double defaultBorderRadius = 12.0;

const String defaultProfilePhotoUrl =
    "https://firebasestorage.googleapis.com/v0/b/pubg-ids-43ac3.appspot.com/o/default-profile-picture.png?alt=media&token=1564f2a9-1190-45ce-a443-7536339cf5ef";

const String termsUrl = 'https://sites.google.com/view/fftermsandcondition';
const String privacyPolicyUrl = 'https://sites.google.com/view/ffidsellingapp';
