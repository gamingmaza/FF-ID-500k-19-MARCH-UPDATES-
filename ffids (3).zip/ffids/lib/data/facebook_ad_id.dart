// class MyFacebookAdIds {
//   static const String bannerAdId = "2082563042104269_2082564465437460";
//   static const String interstitialAdId = "2082563042104269_2082672058760034";
// }

// // Facebook banner - 743629644399696_743634607732533
// // Interstitial - 743629644399696_743640877731906
// // property_id=2550140628502020