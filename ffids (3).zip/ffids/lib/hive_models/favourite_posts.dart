import 'package:hive_flutter/hive_flutter.dart';

part 'favourite_posts.g.dart';

@HiveType(typeId: 0)
class FavouritePosts {
  @HiveField(0)
  String docId;
  @HiveField(1)
  String title;
  @HiveField(2)
  String imageUrl;
  @HiveField(3)
  num price;

  FavouritePosts(this.docId, this.title, this.imageUrl, this.price);
}
