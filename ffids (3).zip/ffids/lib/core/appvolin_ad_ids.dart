// const String sdkKey =
//     "V9LXK1EOGduqEmgk3eKrl8SI9JpmDdCHkmuis3asolW4aFhbSiqv4DJeDKOIx3cNit6oX6oqy7uBFQiaAE2x5l";
// const String intertitialAdId = "f93c56d95e7d49fd";
// //const String bannerAdId = "87bb912d7a711196";
// const String rewardAdId = "d409528327fc7545";

// //admob ids
// const String inersttialAdAdmobId =
//     "/21753324030,23102820484/com.ffidbuysell.app_Interstitial";
