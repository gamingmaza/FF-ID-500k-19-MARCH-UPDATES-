import 'dart:developer';

import 'package:firebase_database/firebase_database.dart';

Future<bool> getValueFromKey() async {
  try {
    final ref = FirebaseDatabase.instance.ref();
    final snapshot = await ref.child('showAd').get();
    if (snapshot.exists) {
      log('ShowAd Value is: ${snapshot.value.toString()}');
      return bool.parse(snapshot.value.toString());
    } else {
      log('No data available for ShowAd Field');
      return false;
    }
  } catch (e) {
    log(e.toString());
    return false;
  }
}
