class AdmobIds {
  static String admobBannerAdId = "ca-app-pub-8166008025765913/9436077674";
  static String appOpenAdId = "ca-app-pub-8166008025765913/7647113586";
  static String interstitalAdId = "ca-app-pub-8166008025765913/2680448705";

// // Test Ad ID for Admob:
//   static String admobBannerAdId = "ca-app-pub-3940256099942544/6300978111";
//   static String appOpenAdId = "ca-app-pub-3940256099942544/9257395921";
//   static String interstitalAdId = "ca-app-pub-3940256099942544/1033173712";
}

class AdxIds {
  static String adxBannerAdID =
      "/21753324030,23102820484/com.ffidbuysell.app_Banner";

  static String adxInterstitalAdID =
      "/21753324030,23102820484/com.ffidbuysell.app_Interstitial";
  static String adxAppOpenAdID =
      "/21753324030,23102820484/com.ffidbuysell.app_AppOpen";
}
