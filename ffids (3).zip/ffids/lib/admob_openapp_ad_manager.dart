// ignore_for_file: unused_field

import 'dart:developer';
import 'package:ffids_dark/core/admob_ad_ids.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'dart:io' show Platform;

class AppOpenAdManager {
  String adUnitId =
      Platform.isAndroid ? AdxIds.adxAppOpenAdID : 'IOS App Open ID';

  AppOpenAd? _appOpenAd;
  final bool _isShowingAd = false;

  /// Load an AppOpenAd.
  void loadAd(Function(AppOpenAd ad) onAdLoadedSuccessfully) {
    AppOpenAd.load(
      adUnitId: adUnitId,
      // adUnitId: "ca-app-pub-3940256099942544/9257395921", // Test AdMob ID
      request: const AdManagerAdRequest(), // ✅ Use AdManagerAdRequest() for AdX
      adLoadCallback: AppOpenAdLoadCallback(
        onAdLoaded: (ad) {
          log('✅ AppOpenAd Loaded Successfully');
          _appOpenAd = ad;
          onAdLoadedSuccessfully(ad);
        },
        onAdFailedToLoad: (error) {
          log('❌ AppOpenAd failed to load: ${error.message}');
          _appOpenAd = null;
        },
      ),
    );
  }

  /// Whether an ad is available to be shown.
  bool get isAdAvailable => _appOpenAd != null;
}
