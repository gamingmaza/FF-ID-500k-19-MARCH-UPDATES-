import 'package:cloud_firestore/cloud_firestore.dart';

import '../data/posts_type.dart';
import '../services/auth_service.dart';

Query<Object?> decidePostQueryByPostType(
    PostsType postsType, CollectionReference ref) {
  switch (postsType) {
    case PostsType.latest:
      return ref.orderBy('date', descending: true);
    case PostsType.popular:
      return ref.orderBy('sellerContactCount', descending: true);
    case PostsType.elitepass:
      return ref
          .where('category', isEqualTo: 'elite_pass')
          .orderBy('date', descending: true);
    case PostsType.diamonds:
      return ref
          .where('category', isEqualTo: 'diamonds')
          .orderBy('date', descending: true);
    case PostsType.gunskins:
      return ref
          .where('category', isEqualTo: 'gun_skins')
          .orderBy('date', descending: true);
    case PostsType.clothes:
      return ref
          .where('category', isEqualTo: 'clothes')
          .orderBy('date', descending: true);
    case PostsType.newId:
      return ref
          .where('category', isEqualTo: 'new')
          .orderBy('date', descending: true);
    case PostsType.myIds:
      return ref
          .where('authorId', isEqualTo: AuthService().user!.uid)
          .orderBy('date', descending: true);
    case PostsType.hasBought:
      return ref.where('boughtBy', isEqualTo: AuthService().user!.uid);
    case PostsType.admin:
      return ref.orderBy('date', descending: true);
  }
}
