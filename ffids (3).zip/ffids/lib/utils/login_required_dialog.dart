import 'package:flutter/material.dart';

import '../data/constants.dart';

loginRequireDialog(BuildContext context) {
  Size deviceSize = MediaQuery.of(context).size;
  final textTheme = Theme.of(context).textTheme;
  showDialog(
    context: context,
    barrierColor: Colors.black38,
    builder: (context) {
      return Padding(
        padding: const EdgeInsets.all(defaultPadding * 2),
        child: Center(
          child: Container(
            width: deviceSize.width,
            height: 250,
            padding: const EdgeInsets.all(defaultPadding),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(defaultBorderRadius),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Attention Required!",
                  style: textTheme.titleLarge,
                ),
                const SizedBox(height: defaultPadding),
                Text(
                  "To access this feature, please log in to your account. Only registered users can enjoy the full benefits of our app.",
                  textAlign: TextAlign.center,
                  style: textTheme.bodyMedium,
                ),
                const SizedBox(height: defaultPadding),
                GestureDetector(
                  onTap: () => Navigator.popUntil(
                    context,
                    ModalRoute.withName('/'),
                  ),
                  child: Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 14,
                    ),
                    width: deviceSize.width / 3,
                    decoration: BoxDecoration(
                      color: primaryColor,
                      borderRadius: BorderRadius.circular(
                        defaultBorderRadius,
                      ),
                    ),
                    child: const DefaultTextStyle(
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                        fontSize: 16,
                        fontFamily: 'Gordita',
                      ),
                      child: Text("Login"),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    },
  );
}
