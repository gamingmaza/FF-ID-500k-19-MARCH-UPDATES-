import 'dart:io';
import 'dart:typed_data';

import 'package:ffids_dark/utils/show_alert.dart';
import 'package:image_picker/image_picker.dart';

Future<Uint8List?> screenshotPicker() async {
  final pickedImage = await ImagePicker().pickImage(
    source: ImageSource.gallery,
    maxWidth: 1080,
    maxHeight: 1080,
  );

  if (pickedImage != null) {
    return File(pickedImage.path).readAsBytesSync();
  } else {
    showInfoAlert(message: "Image not found");
    return null;
  }
}
