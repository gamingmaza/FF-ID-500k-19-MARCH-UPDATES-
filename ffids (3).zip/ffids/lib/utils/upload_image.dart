import 'dart:typed_data';

import 'package:firebase_storage/firebase_storage.dart';

Future<String?> uploadImageToFirebase(String folder, Uint8List bytes) async {
  String uid = DateTime.now().toString();
  uid = uid.replaceAll(RegExp(r'[^\w\s]+'), '').replaceAll(" ", '');

  Reference reference = FirebaseStorage.instance.ref();
  reference = reference.child(folder).child('$uid.jpg');
  UploadTask uploadTask = reference.putData(bytes);
  TaskSnapshot taskSnapshot = await uploadTask;

  return await taskSnapshot.ref.getDownloadURL();
}
