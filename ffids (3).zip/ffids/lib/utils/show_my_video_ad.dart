// import 'package:ffids_dark/providers/my_ads.dart';
// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
// import 'package:video_player/video_player.dart';

// import '../widgets/my_ad_widgets/my_video_ad.dart';

// void showMyVideoAd({required BuildContext context}) {
//   final videoAd = Provider.of<MyAdProvider>(context, listen: false).video;
//   VideoPlayerController? controller;
//   if (videoAd != null) {
//     if (videoAd.videoUrl.isNotEmpty) {
//       controller = VideoPlayerController.networkUrl(
//         Uri.parse(videoAd.videoUrl),
//       );
//       controller.initialize().then((_) {
//         showDialog(
//           context: context,
//           builder: (context) => MyVideoAdDialog(
//             controller: controller,
//             videoAd: videoAd,
//           ),
//         );
//       });
//     } else {
//       showDialog(
//         context: context,
//         builder: (context) => MyVideoAdDialog(videoAd: videoAd),
//       );
//     }
//   }
// }
