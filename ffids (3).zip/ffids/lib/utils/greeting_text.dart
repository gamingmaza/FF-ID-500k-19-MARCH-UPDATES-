String getGreetingText() {
  var hours = DateTime.now().hour;
  if (hours < 12) {
    return "Good Morning!";
  } else if (hours < 17) {
    return "Good Afternoon!";
  } else if (hours < 20) {
    return "Good Evening!";
  } else {
    return "Welcome";
  }
}
