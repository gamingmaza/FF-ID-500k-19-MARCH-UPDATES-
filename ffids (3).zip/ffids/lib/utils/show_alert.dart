import 'dart:ui';

import 'package:fluttertoast/fluttertoast.dart';

void showInfoAlert({required String message}) {
  Fluttertoast.showToast(
    msg: message,
    backgroundColor: const Color(0xFFFFFFFF),
  );
}

void showSuccessAlert({required String message}) {
  Fluttertoast.showToast(
    msg: message,
    backgroundColor: const Color(0xFF00FF00),
  );
}

void showErrorAlert({required String message}) {
  Fluttertoast.showToast(
    msg: message,
    backgroundColor: const Color(0xFFFF0000),
  );
}
