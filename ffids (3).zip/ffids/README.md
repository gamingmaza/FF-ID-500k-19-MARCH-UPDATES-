# com.example.ffids_dark
This repository contains the source code for FFF IDs, a private Free Fire account marketplace app developed for a client. The app enables users to buy, sell, and trade Free Fire accounts and related items securely. 
Note: This project is private and intended for client use only.
