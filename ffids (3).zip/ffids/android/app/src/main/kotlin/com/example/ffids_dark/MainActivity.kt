package com.example.ffids_dark

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
